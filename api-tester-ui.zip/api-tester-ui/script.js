// API Tester JavaScript

class APITester {
    constructor() {
        this.requestHistory = JSON.parse(localStorage.getItem('apiTesterHistory')) || [];
        console.log('📚 생성자에서 불러온 히스토리:', this.requestHistory.length, '개 항목');
        if (this.requestHistory.length > 0) {
            console.log('📚 첫 번째 히스토리 항목:', this.requestHistory[0]);
        }
        this.initializeEventListeners();
        this.loadHistory();
        this.setDefaultValues();
        
        // DOM이 완전히 로드된 후 최근 테스트 결과 로드
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                setTimeout(() => this.loadLastTestResult(), 100);
            });
        } else {
            setTimeout(() => this.loadLastTestResult(), 100);
        }
    }

    initializeEventListeners() {
        // 탭 이벤트
        document.querySelectorAll('.tab-button').forEach(button => {
            button.addEventListener('click', (e) => this.switchTab(e.target.dataset.tab));
        });

        document.querySelectorAll('.response-tab-button').forEach(button => {
            button.addEventListener('click', (e) => this.switchResponseTab(e.target.dataset.tab));
        });

        // 전송 버튼
        document.getElementById('sendButton').addEventListener('click', () => this.sendRequest());

        // Enter 키로 전송
        document.getElementById('apiUrl').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.sendRequest();
        });

        // Headers 관련
        document.getElementById('addHeaderBtn').addEventListener('click', () => this.addHeaderRow());

        // Body 타입 변경
        document.getElementById('bodyType').addEventListener('change', (e) => this.switchBodyType(e.target.value));

        // Form data 추가
        document.getElementById('addFormDataBtn').addEventListener('click', () => this.addFormDataRow());

        // Params 추가
        document.getElementById('addParamBtn').addEventListener('click', () => this.addParamRow());

        // 응답 관련
        document.getElementById('formatJsonBtn').addEventListener('click', () => this.formatJsonResponse());
        document.getElementById('copyResponseBtn').addEventListener('click', () => this.copyResponse());

        // 히스토리 관련
        document.getElementById('clearHistoryBtn').addEventListener('click', () => this.clearHistory());
    }

    setDefaultValues() {
        // 기본 URL 설정 (테스트용)
        document.getElementById('apiUrl').value = 'https://jsonplaceholder.typicode.com/posts/1';
        
        // 기본 헤더 추가
        const firstHeaderKey = document.querySelector('.header-key');
        const firstHeaderValue = document.querySelector('.header-value');
        if (firstHeaderKey && firstHeaderValue) {
            firstHeaderKey.value = 'Content-Type';
            firstHeaderValue.value = 'application/json';
        }
    }

    // 탭 전환
    switchTab(tabName) {
        // 모든 탭 비활성화
        document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));

        // 선택된 탭 활성화
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
        document.getElementById(`${tabName}-tab`).classList.add('active');
    }

    // 응답 탭 전환
    switchResponseTab(tabName) {
        document.querySelectorAll('.response-tab-button').forEach(btn => btn.classList.remove('active'));
        document.querySelectorAll('.response-tab-content').forEach(content => content.classList.remove('active'));

        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
        document.getElementById(`${tabName}-tab`).classList.add('active');
    }

    // Header 행 추가
    addHeaderRow() {
        const container = document.getElementById('headersContainer');
        const newRow = document.createElement('div');
        newRow.className = 'header-row';
        newRow.innerHTML = `
            <input type="text" placeholder="Key" class="header-key">
            <input type="text" placeholder="Value" class="header-value">
            <button class="remove-button" onclick="removeHeaderRow(this)">
                <i class="fas fa-trash"></i>
            </button>
        `;
        container.appendChild(newRow);
    }

    // Form data 행 추가
    addFormDataRow() {
        const container = document.getElementById('formDataContainer');
        const newRow = document.createElement('div');
        newRow.className = 'form-data-row';
        newRow.innerHTML = `
            <input type="text" placeholder="Key" class="form-key">
            <input type="text" placeholder="Value" class="form-value">
            <button class="remove-button" onclick="removeFormRow(this)">
                <i class="fas fa-trash"></i>
            </button>
        `;
        container.appendChild(newRow);
    }

    // Param 행 추가
    addParamRow() {
        const container = document.getElementById('paramsContainer');
        const newRow = document.createElement('div');
        newRow.className = 'param-row';
        newRow.innerHTML = `
            <input type="text" placeholder="Key" class="param-key">
            <input type="text" placeholder="Value" class="param-value">
            <button class="remove-button" onclick="removeParamRow(this)">
                <i class="fas fa-trash"></i>
            </button>
        `;
        container.appendChild(newRow);
    }

    // Body 타입 전환
    switchBodyType(type) {
        const jsonBody = document.getElementById('jsonBody');
        const formBody = document.getElementById('formBody');

        if (type === 'form') {
            jsonBody.style.display = 'none';
            formBody.style.display = 'block';
        } else {
            jsonBody.style.display = 'block';
            formBody.style.display = 'none';
        }
    }

    // Headers 수집
    collectHeaders() {
        const headers = {};
        document.querySelectorAll('.header-row').forEach(row => {
            const key = row.querySelector('.header-key').value.trim();
            const value = row.querySelector('.header-value').value.trim();
            if (key && value) {
                headers[key] = value;
            }
        });
        return headers;
    }

    // Parameters 수집
    collectParams() {
        const params = new URLSearchParams();
        document.querySelectorAll('.param-row').forEach(row => {
            const key = row.querySelector('.param-key').value.trim();
            const value = row.querySelector('.param-value').value.trim();
            if (key && value) {
                params.append(key, value);
            }
        });
        return params;
    }

    // Body 수집
    collectBody() {
        const bodyType = document.getElementById('bodyType').value;
        
        if (bodyType === 'json') {
            const jsonText = document.getElementById('jsonBodyText').value.trim();
            if (jsonText) {
                try {
                    JSON.parse(jsonText); // 유효성 검사
                    return jsonText;
                } catch (e) {
                    throw new Error('Invalid JSON format');
                }
            }
            return null;
        } else if (bodyType === 'form') {
            const formData = new FormData();
            document.querySelectorAll('.form-data-row').forEach(row => {
                const key = row.querySelector('.form-key').value.trim();
                const value = row.querySelector('.form-value').value.trim();
                if (key && value) {
                    formData.append(key, value);
                }
            });
            return formData;
        } else {
            return document.getElementById('jsonBodyText').value.trim() || null;
        }
    }

    // API 요청 전송
    async sendRequest() {
        const url = document.getElementById('apiUrl').value.trim();
        const method = document.getElementById('httpMethod').value;

        if (!url) {
            alert('URL을 입력해주세요.');
            return;
        }

        // 응답 정보 초기화
        this.resetResponseInfo();

        // 로딩 표시
        this.showLoading(true);

        const startTime = Date.now();
        let finalUrl = url;

        try {
            // URL에 파라미터 추가
            const params = this.collectParams();
            if (params.toString()) {
                finalUrl += (url.includes('?') ? '&' : '?') + params.toString();
            }

            // Headers 수집
            const headers = this.collectHeaders();

            // 요청 옵션 구성
            const requestOptions = {
                method: method,
                headers: headers
            };

            // Body 추가 (GET, HEAD 제외)
            if (!['GET', 'HEAD'].includes(method)) {
                try {
                    const body = this.collectBody();
                    if (body) {
                        if (body instanceof FormData) {
                            requestOptions.body = body;
                            // FormData 사용 시 Content-Type 헤더 제거 (브라우저가 자동 설정)
                            delete requestOptions.headers['Content-Type'];
                        } else {
                            requestOptions.body = body;
                        }
                    }
                } catch (error) {
                    this.showLoading(false);
                    alert('Body 형식 오류: ' + error.message);
                    return;
                }
            }

            // API 호출
            console.log('Request:', requestOptions);
            const response = await fetch(finalUrl, requestOptions);
            const endTime = Date.now();
            const responseTime = endTime - startTime;

            // 응답 처리
            await this.handleResponse(response, responseTime, {
                method,
                url: finalUrl,
                headers,
                body: requestOptions.body
            });

        } catch (error) {
            console.error('Request failed:', error);
            const responseTime = Date.now() - startTime;
            
            // 요청 데이터 구성
            const requestData = {
                method,
                url: finalUrl,
                headers: headers || {},
                body: requestOptions && requestOptions.body ? requestOptions.body : null
            };
            
            // 실패한 요청도 히스토리에 저장 (완전한 오류 응답 정보 포함)
            const errorBody = `Error: ${error.message}\n\nThis might be due to:\n- CORS policy restrictions\n- Network connectivity issues\n- Invalid URL\n- Server not responding`;
            
            this.addToHistory({
                ...requestData,
                response: {
                    status: 0,
                    statusText: 'Network Error',
                    headers: {},
                    body: errorBody,
                    time: responseTime,
                    size: new Blob([errorBody]).size,
                    error: error.message
                },
                timestamp: new Date()
            });
            
            this.showError(error, responseTime, requestData);
        } finally {
            this.showLoading(false);
        }
    }

    // 응답 처리
    async handleResponse(response, responseTime, requestData) {
        try {
            // 응답 헤더 수집
            const responseHeaders = {};
            response.headers.forEach((value, key) => {
                responseHeaders[key] = value;
            });

            // 응답 본문 읽기
            const contentType = response.headers.get('content-type') || '';
            let responseBody;
            let responseSize = 0;

            try {
                if (contentType.includes('application/json')) {
                    responseBody = await response.json();
                    responseBody = JSON.stringify(responseBody, null, 2);
                } else {
                    responseBody = await response.text();
                }
                responseSize = new Blob([responseBody]).size;
            } catch (e) {
                responseBody = 'Response body could not be parsed';
            }

            // 응답 데이터 구성
            const responseData = {
                status: response.status,
                statusText: response.statusText,
                headers: responseHeaders,
                body: responseBody,
                time: responseTime,
                size: responseSize,
                success: response.ok
            };

            // 응답 상태 표시
            this.displayResponse(responseData);

            // 최근 테스트 결과 저장 (모든 응답)
            this.saveLastTestResult(requestData, responseData);
            console.log('💾 최근 테스트 결과 저장 완료:', responseData.status, responseData.statusText);

            // 히스토리에 추가 (완전한 응답 정보 포함)
            this.addToHistory({
                ...requestData,
                response: {
                    status: response.status,
                    statusText: response.statusText,
                    headers: responseData.headers,
                    body: responseData.body,
                    time: responseTime,
                    size: responseData.size
                },
                timestamp: new Date()
            });

        } catch (error) {
            console.error('Response handling failed:', error);
            this.showError(error, responseTime);
        }
    }

    // 응답 표시
    displayResponse(responseData) {
        // Status Code와 Status Text 분리 표시
        const statusCodeElement = document.getElementById('responseStatusCode');
        const statusTextElement = document.getElementById('responseStatusText');
        const timeElement = document.getElementById('responseTime');
        const sizeElement = document.getElementById('responseSize');

        statusCodeElement.textContent = responseData.status;
        statusTextElement.textContent = responseData.statusText;
        
        // Status Code 색상 설정
        statusCodeElement.className = 'status-code';
        if (responseData.status >= 200 && responseData.status < 300) {
            statusCodeElement.classList.add('success');
        } else if (responseData.status >= 400) {
            statusCodeElement.classList.add('error');
        } else if (responseData.status >= 300) {
            statusCodeElement.classList.add('warning');
        } else {
            statusCodeElement.classList.add('info');
        }
        
        timeElement.textContent = `${responseData.time}ms`;
        sizeElement.textContent = `${this.formatBytes(responseData.size)}`;

        // 응답 본문 표시
        document.getElementById('responseBody').textContent = responseData.body;

        // 응답 헤더 표시
        const headersText = Object.entries(responseData.headers)
            .map(([key, value]) => `${key}: ${value}`)
            .join('\n');
        document.getElementById('responseHeaders').textContent = headersText;

        // 응답 섹션에 성공/실패 클래스 추가
        const responseSection = document.querySelector('.response-section');
        responseSection.classList.remove('success', 'error');
        responseSection.classList.add(responseData.success ? 'success' : 'error');
    }

    // 오류 표시
    showError(error, responseTime, requestData) {
        const errorResponseData = {
            status: 0,
            statusText: 'Network Error',
            headers: {},
            body: `Error: ${error.message}\n\nThis might be due to:\n- CORS policy restrictions\n- Network connectivity issues\n- Invalid URL\n- Server not responding`,
            time: responseTime,
            size: 0,
            success: false
        };
        
        this.displayResponse(errorResponseData);
        
        // 오류 결과도 저장
        if (requestData) {
            this.saveLastTestResult(requestData, errorResponseData);
            console.log('💾 오류 결과 저장 완료:', error.message);
        }
    }

    // 응답 정보 초기화
    resetResponseInfo() {
        const statusCodeElement = document.getElementById('responseStatusCode');
        const statusTextElement = document.getElementById('responseStatusText');
        const timeElement = document.getElementById('responseTime');
        const sizeElement = document.getElementById('responseSize');

        // 기본값으로 초기화
        statusCodeElement.textContent = '-';
        statusTextElement.textContent = '-';
        timeElement.textContent = '-';
        sizeElement.textContent = '-';

        // 클래스 초기화
        statusCodeElement.className = 'status-code';
        
        // 응답 본문과 헤더 초기화
        document.getElementById('responseBody').textContent = '응답이 여기에 표시됩니다...';
        document.getElementById('responseHeaders').textContent = '응답 헤더가 여기에 표시됩니다...';

        // 응답 섹션 클래스 초기화
        const responseSection = document.querySelector('.response-section');
        responseSection.classList.remove('success', 'error');
    }

    // 최근 테스트 결과 저장
    saveLastTestResult(requestData, responseData) {
        console.log('💾 최근 테스트 결과 저장 시작...', requestData.method, requestData.url);
        
        const lastTestResult = {
            request: {
                url: requestData.url,
                method: requestData.method,
                headers: requestData.headers
            },
            response: responseData,
            timestamp: new Date().toISOString()
        };
        
        console.log('📋 저장할 데이터:', lastTestResult);
        localStorage.setItem('lastTestResult', JSON.stringify(lastTestResult));
        console.log('✅ localStorage에 저장 완료');
    }

    // 헤더 정보 복원
    restoreHeaders(headers) {
        if (!headers || Object.keys(headers).length === 0) return;
        
        // 기존 헤더 행들을 모두 제거 (첫 번째 행 제외)
        const headerRows = document.querySelectorAll('.header-row');
        for (let i = 1; i < headerRows.length; i++) {
            headerRows[i].remove();
        }
        
        // 헤더 정보 복원
        const headerEntries = Object.entries(headers);
        headerEntries.forEach(([key, value], index) => {
            if (index === 0) {
                // 첫 번째 헤더는 기존 행 사용
                const firstKeyInput = document.querySelector('.header-key');
                const firstValueInput = document.querySelector('.header-value');
                if (firstKeyInput && firstValueInput) {
                    firstKeyInput.value = key;
                    firstValueInput.value = value;
                }
            } else {
                // 추가 헤더는 새 행 생성
                this.addHeaderRow();
                const newRows = document.querySelectorAll('.header-row');
                const lastRow = newRows[newRows.length - 1];
                const keyInput = lastRow.querySelector('.header-key');
                const valueInput = lastRow.querySelector('.header-value');
                if (keyInput && valueInput) {
                    keyInput.value = key;
                    valueInput.value = value;
                }
            }
        });
    }

    // 최근 테스트 결과 로드
    loadLastTestResult() {
        console.log('🔄 최근 테스트 결과 로드 시작...');
        
        try {
            const lastResult = localStorage.getItem('lastTestResult');
            console.log('📦 localStorage에서 가져온 데이터:', lastResult ? '데이터 있음' : '데이터 없음');
            
            if (lastResult) {
                const data = JSON.parse(lastResult);
                console.log('📋 파싱된 데이터:', data);
                
                // 24시간 이내의 결과만 표시
                const timestamp = new Date(data.timestamp);
                const now = new Date();
                const hoursDiff = (now - timestamp) / (1000 * 60 * 60);
                
                console.log(`⏰ 시간 확인: ${hoursDiff.toFixed(2)}시간 전 데이터`);
                
                if (hoursDiff <= 24) {
                    console.log('✅ 24시간 이내 데이터 - 복원 시작...');
                    
                    // 요청 정보 복원
                    const urlElement = document.getElementById('apiUrl');
                    const methodElement = document.getElementById('httpMethod');
                    
                    if (urlElement && methodElement) {
                        urlElement.value = data.request.url;
                        methodElement.value = data.request.method;
                        console.log('📝 요청 정보 복원 완료:', data.request.method, data.request.url);
                    }
                    
                    // 헤더 정보 복원
                    if (data.request.headers) {
                        this.restoreHeaders(data.request.headers);
                        console.log('📋 헤더 정보 복원 완료');
                    }
                    
                    // 응답 정보 표시
                    if (data.response) {
                        this.displayResponse(data.response);
                        console.log('🎯 응답 정보 표시 완료:', data.response.status, data.response.statusText);
                    }
                    
                    console.log('✅ 최근 테스트 결과 로드 완료:', data.request.url);
                } else {
                    console.log('⚠️ 24시간이 지난 데이터 - 삭제');
                    localStorage.removeItem('lastTestResult');
                }
            } else {
                console.log('ℹ️ 저장된 최근 테스트 결과가 없습니다');
            }
        } catch (error) {
            console.error('❌ 최근 테스트 결과 로드 실패:', error);
            localStorage.removeItem('lastTestResult');
        }
    }

    // 로딩 표시
    showLoading(show) {
        const spinner = document.getElementById('loadingSpinner');
        const button = document.getElementById('sendButton');
        
        if (show) {
            spinner.style.display = 'block';
            button.disabled = true;
            button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 전송 중...';
        } else {
            spinner.style.display = 'none';
            button.disabled = false;
            button.innerHTML = '<i class="fas fa-paper-plane"></i> 전송';
        }
    }

    // JSON 포맷팅
    formatJsonResponse() {
        const responseBody = document.getElementById('responseBody');
        try {
            const parsed = JSON.parse(responseBody.textContent);
            responseBody.textContent = JSON.stringify(parsed, null, 2);
        } catch (e) {
            alert('유효한 JSON이 아닙니다.');
        }
    }

    // 응답 복사
    async copyResponse() {
        const responseBody = document.getElementById('responseBody').textContent;
        try {
            await navigator.clipboard.writeText(responseBody);
            
            const button = document.getElementById('copyResponseBtn');
            const originalText = button.innerHTML;
            button.innerHTML = '<i class="fas fa-check"></i> 복사됨!';
            setTimeout(() => {
                button.innerHTML = originalText;
            }, 2000);
        } catch (err) {
            alert('복사에 실패했습니다.');
        }
    }

    // 히스토리에 추가
    addToHistory(requestData) {
        console.log('📚 히스토리에 추가할 데이터:', requestData);
        console.log('📚 응답 정보 상세:', requestData.response);
        
        this.requestHistory.unshift(requestData);
        
        // 최대 50개까지만 저장
        if (this.requestHistory.length > 50) {
            this.requestHistory = this.requestHistory.slice(0, 50);
        }
        
        localStorage.setItem('apiTesterHistory', JSON.stringify(this.requestHistory));
        console.log('✅ 히스토리 저장 완료, 총 항목:', this.requestHistory.length);
        this.loadHistory();
    }

    // 히스토리 로드
    loadHistory() {
        const container = document.getElementById('historyContainer');
        
        if (this.requestHistory.length === 0) {
            container.innerHTML = '<p class="no-history">아직 요청 기록이 없습니다.</p>';
            return;
        }

        container.innerHTML = this.requestHistory.map((item, index) => {
            // 응답 상태에 따른 아이콘과 색상 결정
            let statusIcon = '';
            let statusClass = '';
            if (item.response) {
                const status = item.response.status;
                if (status >= 200 && status < 300) {
                    statusIcon = '<i class="fas fa-check-circle"></i>';
                    statusClass = 'success';
                } else if (status >= 400) {
                    statusIcon = '<i class="fas fa-times-circle"></i>';
                    statusClass = 'error';
                } else if (status >= 300) {
                    statusIcon = '<i class="fas fa-exclamation-triangle"></i>';
                    statusClass = 'warning';
                } else {
                    statusIcon = '<i class="fas fa-info-circle"></i>';
                    statusClass = 'info';
                }
            } else {
                statusIcon = '<i class="fas fa-question-circle"></i>';
                statusClass = 'unknown';
            }

            return `
                <div class="history-item ${statusClass}">
                    <div class="history-status">
                        ${statusIcon}
                    </div>
                    <div class="history-main" onclick="apiTester.loadFromHistory(${index})">
                        <div class="history-request">
                            <span class="history-method ${item.method}">${item.method}</span>
                            <span class="history-url">${item.url}</span>
                        </div>
                        <div class="history-time">
                            ${new Date(item.timestamp).toLocaleString()} 
                            ${item.response ? `• <span class="status-code-small ${statusClass}">${item.response.status}</span> • ${item.response.time}ms` : ''}
                        </div>
                    </div>
                    <div class="history-actions">
                        <button class="history-monitor-btn" onclick="apiTester.createMonitorFromHistory(${index})" title="모니터링으로 등록">
                            <i class="fas fa-chart-line"></i>
                        </button>
                    </div>
                </div>
            `;
        }).join('');
    }

    // 히스토리에서 불러오기
    loadFromHistory(index) {
        const item = this.requestHistory[index];
        if (!item) return;

        console.log('📋 히스토리에서 불러오기:', item);

        // URL과 메서드 설정
        document.getElementById('apiUrl').value = item.url.split('?')[0]; // 파라미터 제외한 URL
        document.getElementById('httpMethod').value = item.method;

        // Headers 설정
        this.clearHeaders();
        if (item.headers) {
            Object.entries(item.headers).forEach(([key, value]) => {
                this.addHeaderRow();
                const rows = document.querySelectorAll('.header-row');
                const lastRow = rows[rows.length - 1];
                lastRow.querySelector('.header-key').value = key;
                lastRow.querySelector('.header-value').value = value;
            });
        }

        // Body 설정
        if (item.body && typeof item.body === 'string') {
            document.getElementById('jsonBodyText').value = item.body;
        }

        // 응답 정보가 있으면 표시
        if (item.response) {
            console.log('🎯 응답 정보 복원:', item.response);
            
            // 응답 데이터 구조 생성
            const responseData = {
                status: item.response.status || 0,
                statusText: item.response.statusText || 'Unknown',
                headers: item.response.headers || {},
                body: item.response.body || '',
                time: item.response.time || 0,
                size: item.response.size || 0,
                success: (item.response.status >= 200 && item.response.status < 300)
            };
            
            // 응답 정보 표시
            this.displayResponse(responseData);
            console.log('✅ 응답 정보 표시 완료');
        } else {
            // 응답 정보가 없으면 초기화
            this.resetResponseInfo();
            console.log('ℹ️ 응답 정보가 없어서 초기화');
        }

        alert('히스토리에서 불러왔습니다!');
    }

    // 히스토리에서 모니터링 생성
    createMonitorFromHistory(index) {
        const item = this.requestHistory[index];
        if (!item) return;

        // Auto Monitor 섹션으로 이동 (URL 라우팅 사용)
        setUrlHash('monitor');
        activateSection('monitor');

        // 잠시 기다린 후 모달 열기 (DOM 업데이트 대기)
        setTimeout(() => {
            if (window.apiMonitor) {
                window.apiMonitor.showAddMonitorModalWithData(item);
            } else {
                alert('모니터링 시스템이 아직 로드되지 않았습니다. 잠시 후 다시 시도해주세요.');
            }
        }, 100);
    }

    // Headers 초기화
    clearHeaders() {
        const container = document.getElementById('headersContainer');
        container.innerHTML = `
            <div class="header-row">
                <input type="text" placeholder="Key" class="header-key">
                <input type="text" placeholder="Value" class="header-value">
                <button class="remove-button" onclick="removeHeaderRow(this)">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;
    }

    // 히스토리 초기화
    clearHistory() {
        if (confirm('모든 요청 기록을 삭제하시겠습니까?')) {
            this.requestHistory = [];
            localStorage.removeItem('apiTesterHistory');
            this.loadHistory();
        }
    }

    // 바이트 포맷팅
    formatBytes(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
}

// 에이전트 연결 정보 닫기 함수
function closeAgentConnectionInfo() {
    document.getElementById('agentConnectionInfo').style.display = 'none';
}

// 에이전트 목록 로드
async function loadAgents() {
    try {
        const response = await fetch('/api/agents');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        displayAgents(data);
        updateAgentStats(data);
    } catch (error) {
        console.error('에이전트 목록 로드 실패:', error);
        displayAgentError('에이전트 목록을 불러올 수 없습니다: ' + error.message);
    }
}

// 에이전트 목록 표시
function displayAgents(data) {
    const agentList = document.getElementById('agentList');
    if (!agentList) return;

    if (!data.agents || data.agents.length === 0) {
        agentList.innerHTML = '<div class="agent-card no-agents"><div class="agent-info"><h3>연결된 에이전트가 없습니다</h3><p>에이전트를 실행하여 연결해주세요.</p></div></div>';
        return;
    }

    agentList.innerHTML = data.agents.map(agent => `
        <div class="agent-card ${agent.status === 'healthy' ? 'online' : 'offline'}">
            <div class="agent-status-indicator"></div>
            <div class="agent-info">
                <h3>${agent.agentName}</h3>
                <p class="agent-id">ID: ${agent.agentId}</p>
                <p class="agent-endpoint">엔드포인트: ${agent.endpoint}</p>
                <p class="agent-platform">${agent.systemInfo.platform} (${agent.systemInfo.arch})</p>
            </div>
            <div class="agent-stats">
                <div class="stat">
                    <span class="stat-label">상태</span>
                    <span class="stat-value ${agent.status === 'healthy' ? 'healthy' : 'offline'}">${agent.status === 'healthy' ? '온라인' : '오프라인'}</span>
                </div>
                <div class="stat">
                    <span class="stat-label">활성 모니터링</span>
                    <span class="stat-value">${agent.activeMonitors || 0}</span>
                </div>
                <div class="stat">
                    <span class="stat-label">최대 동시 작업</span>
                    <span class="stat-value">${agent.capabilities?.maxConcurrentMonitors || 0}</span>
                </div>
                <div class="stat">
                    <span class="stat-label">가동 시간</span>
                    <span class="stat-value">${formatUptime(agent.uptime)}</span>
                </div>
                <div class="stat">
                    <span class="stat-label">마지막 확인</span>
                    <span class="stat-value">${formatLastSeen(agent.lastSeen)}</span>
                </div>
            </div>
            <div class="agent-actions">
                <button class="btn btn-secondary" onclick="viewAgentDetails('${agent.agentId}')">세부정보</button>
                <button class="btn btn-primary" onclick="assignMonitorToAgent('${agent.agentId}')">모니터링 할당</button>
                ${agent.status === 'healthy' ? '<button class="btn btn-warning" onclick="pingAgent(\'' + agent.agentId + '\')">핑 테스트</button>' : ''}
            </div>
        </div>
    `).join('');
}

// 에이전트 통계 업데이트 및 헬퍼 함수들
function updateAgentStats(data) {
    const elements = {
        totalAgents: document.getElementById('totalAgents'),
        onlineAgents: document.getElementById('onlineAgents'),
        offlineAgents: document.getElementById('offlineAgents')
    };
    if (elements.totalAgents) elements.totalAgents.textContent = data.total || 0;
    if (elements.onlineAgents) elements.onlineAgents.textContent = data.online || 0;
    if (elements.offlineAgents) elements.offlineAgents.textContent = data.offline || 0;
}

function displayAgentError(message) {
    const agentList = document.getElementById('agentList');
    if (!agentList) return;
    agentList.innerHTML = '<div class="agent-card error"><div class="agent-info"><h3>❌ 오류</h3><p>' + message + '</p><button class="btn btn-primary" onclick="loadAgents()">다시 시도</button></div></div>';
}

function formatUptime(seconds) {
    if (!seconds) return '-';
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return hours > 0 ? hours + '시간 ' + minutes + '분' : minutes + '분';
}

function formatLastSeen(timestamp) {
    if (!timestamp) return '-';
    const diffSeconds = Math.floor((new Date() - new Date(timestamp)) / 1000);
    if (diffSeconds < 60) return '방금 전';
    else if (diffSeconds < 3600) return Math.floor(diffSeconds / 60) + '분 전';
    else return Math.floor(diffSeconds / 3600) + '시간 전';
}

function viewAgentDetails(agentId) {
    alert('에이전트 세부정보 기능은 곧 추가될 예정입니다.');
}

function assignMonitorToAgent(agentId) {
    alert('모니터링 할당 기능은 곧 추가될 예정입니다.');
}

async function pingAgent(agentId) {
    try {
        const agentsResponse = await fetch('/api/agents');
        const agentsData = await agentsResponse.json();
        const agent = agentsData.agents.find(a => a.agentId === agentId);
        if (!agent) throw new Error('에이전트를 찾을 수 없습니다');
        const startTime = performance.now();
        const pingResponse = await fetch(agent.endpoint + '/health');
        const endTime = performance.now();
        const pingData = await pingResponse.json();
        const responseTime = Math.round(endTime - startTime);
        alert('🟢 에이전트 핑 성공!\n상태: ' + pingData.status + '\n응답시간: ' + responseTime + 'ms');
    } catch (error) {
        alert('🔴 에이전트 핑 실패: ' + error.message);
    }
}

// 글로벌 함수들 (HTML에서 직접 호출됨)
function removeHeaderRow(button) {
    const rows = document.querySelectorAll('.header-row');
    if (rows.length > 1) {
        button.parentElement.remove();
    }
}

function removeFormRow(button) {
    const rows = document.querySelectorAll('.form-data-row');
    if (rows.length > 1) {
        button.parentElement.remove();
    }
}

function removeParamRow(button) {
    const rows = document.querySelectorAll('.param-row');
    if (rows.length > 1) {
        button.parentElement.remove();
    }
}

// URL 라우팅 함수들
function getHashFromUrl() {
    return window.location.hash.replace('#', '') || 'tester';
}

function setUrlHash(section) {
    const newHash = '#' + section;
    if (window.location.hash !== newHash) {
        window.history.pushState(null, null, newHash);
    }
}

function activateSection(targetSection) {
    const navButtons = document.querySelectorAll('.nav-button');
    const sections = document.querySelectorAll('.main-section');
    
    // 유효한 섹션인지 확인
    const validSections = ['tester', 'monitor', 'dashboard', 'agents'];
    if (!validSections.includes(targetSection)) {
        targetSection = 'tester';
    }
    
    // 모든 버튼과 섹션에서 활성 클래스 제거
    navButtons.forEach(btn => btn.classList.remove('active'));
    sections.forEach(section => section.classList.remove('active'));
    
    // 해당 버튼과 섹션 활성화
    const targetButton = document.querySelector(`[data-section="${targetSection}"]`);
    const targetSectionElement = document.getElementById(targetSection + '-section');
    
    if (targetButton && targetSectionElement) {
        targetButton.classList.add('active');
        targetSectionElement.classList.add('active');
        
        // 페이지 제목 업데이트
        const sectionTitles = {
            'tester': 'Manual Test - API Tester',
            'monitor': 'Auto Monitor - API Tester', 
            'dashboard': 'Dashboard - API Tester',
            'agents': 'Agent Management - API Tester'
        };
        document.title = sectionTitles[targetSection] || 'API Tester - Web UI';
        
        // 응답 섹션과 히스토리 섹션 표시 제어
        const responseSection = document.querySelector('.response-section');
        const historySection = document.querySelector('.history-section');
        
        if (targetSection === 'tester') {
            // Manual Test 탭: 응답 섹션과 히스토리 섹션 모두 표시
            if (responseSection) responseSection.style.display = 'block';
            if (historySection) historySection.style.display = 'block';
        } else if (targetSection === 'dashboard') {
            // Dashboard 탭: 응답 섹션만 표시 (히스토리는 숨김)
            if (responseSection) responseSection.style.display = 'block';
            if (historySection) historySection.style.display = 'none';
        } else if (targetSection === 'agents') {
            // Agents 탭: 응답 섹션과 히스토리 섹션 모두 숨김
            if (responseSection) responseSection.style.display = 'none';
            if (historySection) historySection.style.display = 'none';
            // 에이전트 데이터 로드
            loadAgents();
        } else {
            // 다른 탭: 응답 섹션과 히스토리 섹션 모두 숨김
            if (responseSection) responseSection.style.display = 'none';
            if (historySection) historySection.style.display = 'none';
        }
        
        // 대시보드 섹션일 때 대시보드 업데이트
        if (targetSection === 'dashboard' && typeof updateDashboard === 'function') {
            setTimeout(() => {
                updateDashboard();
                console.log('🔄 대시보드 섹션 활성화 - 대시보드 업데이트 완료');
            }, 100);
        }
        
        console.log(`🔗 섹션 변경: ${targetSection}`);
    }
}

// 네비게이션 설정
function setupNavigation() {
    const navButtons = document.querySelectorAll('.nav-button');
    
    navButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault();
            const targetSection = button.getAttribute('data-section');
            
            // URL hash 업데이트
            setUrlHash(targetSection);
            
            // 해당 섹션 활성화
            activateSection(targetSection);
        });
    });
    
    // 브라우저 뒤로가기/앞으로가기 이벤트 처리
    window.addEventListener('popstate', () => {
        const currentSection = getHashFromUrl();
        activateSection(currentSection);
    });
    
    // 페이지 로드 시 URL hash에 따른 초기 섹션 설정
    const initialSection = getHashFromUrl();
    setUrlHash(initialSection); // URL을 정규화
    activateSection(initialSection);
}

// 앱 초기화
let apiTester;
document.addEventListener('DOMContentLoaded', () => {
    // 네비게이션 설정
    setupNavigation();
    
    // API Tester 초기화
    apiTester = new APITester();
    console.log('API Tester 초기화 완료!');
}); 