# API Tester & Monitor - Web UI 🚀

**Postman + 자동 모니터링 기능을 제공하는 웹 기반 API 테스트 도구**

간편하고 직관적인 웹 인터페이스로 REST API를 테스트하고, 자동으로 모니터링할 수 있습니다.

![API Tester Preview](https://via.placeholder.com/800x400/667eea/ffffff?text=API+Tester+Web+UI)

## ✨ 주요 기능

### 🎯 세 가지 주요 모드
- **📡 Manual Test**: 수동 API 테스트 (기존 Postman 기능)
- **🤖 Auto Monitor**: 자동 API 모니터링 (새로운 기능!)
- **📊 Dashboard**: 모니터링 결과 대시보드

### 📡 Manual Test (수동 테스트)

#### 🌐 HTTP 메서드 지원
- **GET, POST, PUT, DELETE, PATCH, HEAD, OPTIONS** 모든 메서드 지원
- 직관적인 드롭다운 메뉴로 쉬운 선택

#### 📋 Headers 관리
- 동적으로 헤더 추가/제거
- 자동완성 지원 (Content-Type, Authorization 등)
- 기본 헤더 자동 설정

#### 📝 Request Body 지원
- **JSON**: 구문 강조 및 유효성 검사
- **Form Data**: Key-Value 형태의 폼 데이터
- **Plain Text**: 원시 텍스트 데이터

#### 🔗 Query Parameters
- URL 파라미터 동적 관리
- 자동으로 URL에 추가

#### 📊 응답 분석
- **상태 코드** 및 **응답 시간** 표시
- **응답 크기** 자동 계산
- **JSON 포맷팅** 기능
- **응답 헤더** 상세 보기

#### 📚 히스토리 관리
- 최근 요청 **50개 자동 저장**
- 히스토리에서 **원클릭 복원**
- **로컬 스토리지** 저장으로 브라우저 재시작 후에도 유지

### 🤖 Auto Monitor (자동 모니터링) ⭐ 신기능!

#### ⏰ 주기적 API 호출
- **1분 ~ 1시간** 간격으로 설정 가능
- 백그라운드에서 자동 실행
- 실시간 상태 업데이트

#### 🔛 모니터링 관리
- **On/Off 스위치**: 언제든지 활성화/비활성화
- **여러 API 동시 모니터링** 가능
- **개별 설정**: 각 API마다 다른 주기 설정

#### 💾 결과 저장 & 관리
- **SQLite 데이터베이스**에 안전하게 저장
- **2년 후 자동 삭제** (데이터 관리)
- 성공/실패 상태 및 응답 시간 기록

#### 🚨 상태 추적
- **실시간 상태 표시**: 대기중/실행중/성공/실패
- **마지막 체크 시간** 표시
- **응답 시간** 및 **에러 메시지** 기록

### 📊 Dashboard (대시보드)

#### 📈 통계 카드
- **성공한 요청 수** 
- **실패한 요청 수**
- **평균 응답 시간**
- **활성 모니터링 수**

#### 📉 시각화 차트
- **응답 시간 추이** 차트 (최근 24시간)
- **성공률** 도넛 차트
- **Chart.js** 기반 인터랙티브 차트

#### 📋 최근 결과 테이블
- **최근 20개 테스트 결과** 표시
- **시간, 모니터링명, 상태, 응답시간** 등 상세 정보
- **실시간 업데이트**

### 🎨 현대적인 UI/UX
- **반응형 디자인** (모바일 지원)
- **다크 모드** 지원
- **애니메이션** 및 **호버 효과**
- **직관적인 탭 구조**

## 🚀 빠른 시작

### 1. 설치
```bash
# 프로젝트 클론 또는 다운로드
cd api-tester-ui

# 의존성 설치
npm install
```

### 2. 실행
```bash
# 서버 시작
npm start

# 또는
npm run dev
```

### 3. 접속
브라우저에서 **http://localhost:3000** 로 접속

서버가 시작되면 자동으로 브라우저가 열립니다! 🎉

## 📖 사용법

### 기본 API 호출
1. **HTTP 메서드** 선택 (GET, POST, PUT 등)
2. **URL** 입력 (예: `https://jsonplaceholder.typicode.com/posts/1`)
3. 필요한 경우 **Headers**, **Body**, **Parameters** 설정
4. **전송** 버튼 클릭 ⚡

### Headers 설정
1. **Headers** 탭 클릭
2. **Key-Value** 형태로 헤더 입력
3. **헤더 추가** 버튼으로 필드 추가
4. 🗑️ 아이콘으로 불필요한 헤더 제거

### Body 데이터 전송 (POST/PUT)
1. **Body** 탭 클릭
2. **데이터 형식** 선택:
   - **JSON**: `{"name": "John", "age": 30}`
   - **Form Data**: Key-Value 형태
   - **Text**: 원시 텍스트
3. 데이터 입력 후 전송

### Query Parameters
1. **Params** 탭 클릭
2. **Key-Value** 형태로 파라미터 입력
3. 자동으로 URL에 `?key=value&key2=value2` 형태로 추가

## 🛠️ 고급 기능

### CORS 이슈 해결
외부 API 호출 시 CORS 오류가 발생한다면:

```javascript
// 기존 URL
https://api.example.com/users

// 프록시 사용
http://localhost:3000/api-proxy/https://api.example.com/users
```

### 응답 데이터 활용
- **Format JSON**: 응답 JSON을 읽기 쉽게 포맷팅
- **Copy**: 응답 데이터를 클립보드에 복사
- **Headers**: 응답 헤더 상세 확인

### 히스토리 활용
- 최근 요청 기록에서 **클릭 한 번**으로 복원
- **Clear** 버튼으로 히스토리 초기화
- 브라우저 **로컬 스토리지**에 자동 저장

## 🎯 예제 API 테스트

### GET 요청 예제
```
URL: https://jsonplaceholder.typicode.com/posts/1
Method: GET
Headers: (기본값)
```

### POST 요청 예제
```
URL: https://jsonplaceholder.typicode.com/posts
Method: POST
Headers: 
  Content-Type: application/json
Body (JSON):
{
  "title": "My Post",
  "body": "This is the content",
  "userId": 1
}
```

### 인증이 필요한 API
```
URL: https://api.github.com/user
Method: GET
Headers:
  Authorization: Bearer your_token_here
  User-Agent: API-Tester
```

## 🔧 개발자 옵션

### 로컬 개발
```bash
# 개발 모드 (파일 변경 감지)
npm run dev

# 프로덕션 모드
npm start
```

### 포트 변경
```bash
# 환경변수로 포트 설정
PORT=8080 npm start
```

### 로그 확인
서버 콘솔에서 모든 API 요청/응답 로그를 확인할 수 있습니다:
```
🔄 Proxying GET https://api.example.com/users
📋 Headers: {...}
✅ Response: 200 OK (150ms)
```

## 🚨 주의사항

### CORS 정책
- 일부 API는 브라우저의 **CORS 정책**으로 인해 직접 호출이 제한될 수 있습니다
- 이 경우 내장된 **프록시 기능**을 사용하세요: `/api-proxy/[원본URL]`

### 보안
- **API 키**나 **인증 토큰**은 안전하게 관리하세요
- 로컬 환경에서만 사용하는 것을 권장합니다

### 브라우저 호환성
- **모던 브라우저** 지원 (Chrome, Firefox, Safari, Edge)
- **ES6+** 문법 사용

## 🎨 커스터마이징

### 테마 변경
`style.css` 파일에서 색상 테마를 수정할 수 있습니다:

```css
/* 메인 색상 변경 */
.send-button {
    background: linear-gradient(135deg, #your-color 0%, #another-color 100%);
}
```

### 기본 설정
`script.js`의 `setDefaultValues()` 함수에서 기본값을 변경할 수 있습니다.

## 📝 라이선스

MIT License - 자유롭게 사용, 수정, 배포 가능합니다.

## 🤝 기여하기

버그 리포트, 기능 제안, Pull Request 모두 환영합니다!

---

**API Tester Web UI**로 더 쉽고 빠른 API 개발을 경험해보세요! 🚀✨
