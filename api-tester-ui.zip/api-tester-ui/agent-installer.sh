#!/bin/bash

# API Monitor Agent 설치 스크립트
# 사용법: bash agent-installer.sh <중앙서버IP>

set -e

CENTRAL_SERVER=${1:-"localhost"}
AGENT_DIR="api-monitor-agent"

echo "🚀 API Monitor Agent 설치를 시작합니다..."
echo "📡 중앙 서버: $CENTRAL_SERVER"

# Node.js 설치 확인
if ! command -v node &> /dev/null; then
    echo "❌ Node.js가 설치되어 있지 않습니다."
    echo "📥 Node.js를 먼저 설치해주세요: https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js 버전: $(node --version)"

# 에이전트 디렉토리 생성
if [ -d "$AGENT_DIR" ]; then
    echo "📁 기존 에이전트 디렉토리를 제거합니다..."
    rm -rf "$AGENT_DIR"
fi

mkdir -p "$AGENT_DIR"
cd "$AGENT_DIR"

echo "📦 에이전트 파일들을 생성합니다..."

# package.json 생성
cat > package.json << 'EOF'
{
  "name": "api-monitor-agent",
  "version": "1.0.0",
  "description": "API Monitor Agent for distributed monitoring",
  "main": "agent.js",
  "scripts": {
    "start": "node agent.js",
    "dev": "nodemon agent.js"
  },
  "dependencies": {
    "ws": "^8.14.2",
    "axios": "^1.6.0"
  },
  "keywords": ["api", "monitor", "agent"],
  "author": "API Monitor Team",
  "license": "MIT"
}
EOF

echo "📝 에이전트 코드를 다운로드합니다..."

# 실제 agent.js 파일을 중앙 서버에서 다운로드
if curl -s "http://$CENTRAL_SERVER:3000/api/agent-code" -o agent.js; then
    echo "✅ 에이전트 코드 다운로드 완료"
    chmod +x agent.js
else
    echo "❌ 중앙 서버에서 에이전트 코드를 다운로드할 수 없습니다."
    echo "🔍 서버 상태를 확인하세요: http://$CENTRAL_SERVER:3000"
    exit 1
fi

# README.md 생성
cat > README.md << 'EOF'
# API Monitor Agent

분산 API 모니터링을 위한 에이전트입니다.

## 설치 및 실행

1. 의존성 설치:
```bash
npm install
```

2. 에이전트 실행:
```bash
npm start
```

## 설정

환경변수로 중앙 서버를 설정할 수 있습니다:
```bash
CENTRAL_SERVER=your-server-ip npm start
```

## 상태 확인

에이전트가 정상적으로 연결되면 중앙 서버 대시보드에서 확인할 수 있습니다.
EOF

echo "📦 의존성을 설치합니다..."
npm install

echo ""
echo "🎉 에이전트 설치가 완료되었습니다!"
echo ""
echo "🚀 에이전트를 시작하려면:"
echo "   cd $AGENT_DIR"
echo "   CENTRAL_SERVER=$CENTRAL_SERVER npm start"
echo ""
echo "📊 중앙 서버 대시보드: http://$CENTRAL_SERVER:3000"
echo "" 