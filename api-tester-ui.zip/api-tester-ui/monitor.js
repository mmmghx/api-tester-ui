// API 모니터링 시스템
class APIMonitor {
    constructor() {
        this.monitors = JSON.parse(localStorage.getItem('apiMonitors')) || [];
        // 기존 결과 데이터 로드 및 오래된 데이터만 정리
        this.results = JSON.parse(localStorage.getItem('apiMonitorResults')) || [];
        this.cleanupOldResults(); // 2년 지난 데이터만 삭제
        this.activeIntervals = new Map();
        this.charts = {};
        this.currentFilter = 'all'; // 필터 상태 초기화
        this.timeOffset = 0; // 현재 시간으로부터의 오프셋 (밀리초)
        
        // 인스턴스 고유 ID 생성 (중복 실행 방지용)
        this.instanceId = Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        this.wasMaster = false; // 이전 마스터 상태 추적
        console.log(`🆔 새로운 APIMonitor 인스턴스 생성: ${this.instanceId}`);
        
        // 다른 탭에서 실행 중인 모니터링 확인
        this.checkForExistingInstances();
        
        this.initializeEventListeners();
        this.loadMonitors();
        
        // 페이지 로드 시 활성 모니터링 복원 (중복 방지 체크 포함)
        this.restoreActiveMonitors();
        
        console.log(`📡 API Monitor 초기화: ${this.monitors.length}개 모니터링, ${this.results.length}개 결과 로드됨`);
        
        // 현재 인스턴스를 활성 인스턴스로 등록
        this.registerAsActiveInstance();
        
        // 초기 대시보드 업데이트 (약간의 지연 후)
        setTimeout(() => {
            if (typeof updateDashboard === 'function') {
                updateDashboard();
                this.updateFilterButtons(); // 필터 버튼 상태 초기화
                this.updateMonitorFilterOptions(); // 모니터 필터 옵션 초기화
                console.log('📊 초기 대시보드 업데이트 완료');
                console.log('🗑️ 2년 지난 오래된 데이터 정리 완료');
            }
        }, 500);
    }

    // 다른 탭에서 실행 중인 인스턴스 확인
    checkForExistingInstances() {
        const existingInstances = JSON.parse(localStorage.getItem('apiMonitorInstances') || '[]');
        const now = Date.now();
        
        // 5분 이상 된 오래된 인스턴스 정리
        const activeInstances = existingInstances.filter(instance => 
            now - instance.timestamp < 5 * 60 * 1000
        );
        
        if (activeInstances.length > 0) {
            console.log(`⚠️ 다른 탭에서 실행 중인 인스턴스 발견: ${activeInstances.length}개`);
            activeInstances.forEach(instance => {
                console.log(`  - Instance ID: ${instance.id}, 생성시간: ${new Date(instance.timestamp).toLocaleTimeString()}`);
            });
        }
        
        // 정리된 목록 저장
        localStorage.setItem('apiMonitorInstances', JSON.stringify(activeInstances));
    }
    
    // 현재 인스턴스를 활성 인스턴스로 등록
    registerAsActiveInstance() {
        const existingInstances = JSON.parse(localStorage.getItem('apiMonitorInstances') || '[]');
        const now = Date.now();
        
        // 현재 인스턴스 추가
        const newInstance = {
            id: this.instanceId,
            timestamp: now,
            url: window.location.href
        };
        
        // 5분 이상 된 오래된 인스턴스 제거하고 현재 인스턴스 추가
        const activeInstances = existingInstances
            .filter(instance => now - instance.timestamp < 5 * 60 * 1000)
            .filter(instance => instance.id !== this.instanceId);
        
        activeInstances.push(newInstance);
        localStorage.setItem('apiMonitorInstances', JSON.stringify(activeInstances));
        
        console.log(`✅ 현재 인스턴스 등록: ${this.instanceId}`);
        console.log(`📊 총 활성 인스턴스 수: ${activeInstances.length}`);
        
        // 주기적으로 하트비트 업데이트
        this.startHeartbeat();
    }
    
    // 하트비트로 인스턴스 활성 상태 유지
    startHeartbeat() {
        this.heartbeatInterval = setInterval(() => {
            const existingInstances = JSON.parse(localStorage.getItem('apiMonitorInstances') || '[]');
            const now = Date.now();
            
            // 현재 인스턴스의 타임스탬프 업데이트
            const updatedInstances = existingInstances.map(instance => {
                if (instance.id === this.instanceId) {
                    return { ...instance, timestamp: now };
                }
                return instance;
            });
            
            // 오래된 인스턴스 제거
            const activeInstances = updatedInstances.filter(instance => 
                now - instance.timestamp < 5 * 60 * 1000
            );
            
            localStorage.setItem('apiMonitorInstances', JSON.stringify(activeInstances));
        }, 30000); // 30초마다 하트비트
    }
    
    // 가장 오래된 인스턴스인지 확인 (마스터 인스턴스)
    isMasterInstance() {
        const existingInstances = JSON.parse(localStorage.getItem('apiMonitorInstances') || '[]');
        const now = Date.now();
        
        // 활성 인스턴스만 필터링
        const activeInstances = existingInstances.filter(instance => 
            now - instance.timestamp < 5 * 60 * 1000
        );
        
        if (activeInstances.length === 0) return true;
        
        // 가장 오래된 인스턴스 찾기
        const oldestInstance = activeInstances.reduce((oldest, current) => 
            current.timestamp < oldest.timestamp ? current : oldest
        );
        
        const isMaster = oldestInstance.id === this.instanceId;
        
        // 마스터 상태 변화 감지 및 로깅
        if (isMaster !== this.wasMaster) {
            if (isMaster) {
                console.log(`👑 마스터 인스턴스로 승격: ${this.instanceId}`);
            } else {
                console.log(`🙇‍♂️ 마스터 역할 양도: ${this.instanceId} (새 마스터: ${oldestInstance.id})`);
            }
        }
        
        return isMaster;
    }
    
    // 페이지 종료 시 정리 작업 설정
    setupCleanupHandlers() {
        // 페이지 언로드 시 인스턴스 정리
        window.addEventListener('beforeunload', () => {
            this.cleanup();
        });
        
        // 페이지 숨김 시 마스터 승계 처리
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                console.log('📴 페이지가 숨겨짐 - 마스터 승계 확인');
                setTimeout(() => {
                    this.checkMasterSuccession();
                }, 2000);
            }
        });
        
        // 주기적으로 마스터 승계 확인
        setInterval(() => {
            this.checkMasterSuccession();
        }, 60000); // 1분마다
    }
    
    // 인스턴스 정리
    cleanup() {
        console.log(`🧹 인스턴스 정리: ${this.instanceId}`);
        
        // 하트비트 중지
        if (this.heartbeatInterval) {
            clearInterval(this.heartbeatInterval);
        }
        
        // 모든 모니터링 interval 정리
        for (let [id, intervalId] of this.activeIntervals) {
            clearInterval(intervalId);
            console.log(`🧹 모니터링 interval 정리: ${id}`);
        }
        this.activeIntervals.clear();
        
        // localStorage에서 현재 인스턴스 제거
        const existingInstances = JSON.parse(localStorage.getItem('apiMonitorInstances') || '[]');
        const filteredInstances = existingInstances.filter(instance => instance.id !== this.instanceId);
        localStorage.setItem('apiMonitorInstances', JSON.stringify(filteredInstances));
        
        console.log(`✅ 인스턴스 정리 완료: ${this.instanceId}`);
    }
    
    // 마스터 승계 확인 및 처리
    checkMasterSuccession() {
        const previousMaster = this.wasMaster;
        const isMasterNow = this.isMasterInstance();
        
        // 새롭게 마스터가 된 경우
        if (!previousMaster && isMasterNow) {
            console.log('👑 마스터 역할 승계 - 모니터링 시작');
            this.wasMaster = true;
            // 약간의 지연 후 모니터링 시작 (다른 인스턴스와의 충돌 방지)
            setTimeout(() => {
                this.restoreActiveMonitors();
            }, 2000);
        }
        // 마스터였지만 더 이상 마스터가 아닌 경우
        else if (previousMaster && !isMasterNow) {
            console.log('🙇‍♂️ 마스터 역할 양도 - 모니터링 중지');
            this.wasMaster = false;
            this.stopAllMonitoring();
        }
        // 현재 상태 업데이트
        else {
            this.wasMaster = isMasterNow;
        }
    }
    
    // 모든 모니터링 중지
    stopAllMonitoring() {
        for (let [id, intervalId] of this.activeIntervals) {
            clearInterval(intervalId);
            console.log(`⏸️ 모니터링 중지: ${id}`);
        }
        this.activeIntervals.clear();
        console.log('⏸️ 모든 모니터링 중지 완료');
    }
    
    // 현재 모니터링 상태 디버깅 정보 출력
    getDebugInfo() {
        const existingInstances = JSON.parse(localStorage.getItem('apiMonitorInstances') || '[]');
        const now = Date.now();
        const activeInstances = existingInstances.filter(instance => 
            now - instance.timestamp < 5 * 60 * 1000
        );
        
        console.log('🔍 === 모니터링 디버그 정보 ===');
        console.log(`🆔 현재 인스턴스: ${this.instanceId}`);
        console.log(`👑 마스터 여부: ${this.wasMaster ? 'YES' : 'NO'}`);
        console.log(`📊 활성 Interval 수: ${this.activeIntervals.size}`);
        console.log(`🏠 총 활성 인스턴스 수: ${activeInstances.length}`);
        
        console.log('📋 활성 인스턴스 목록:');
        activeInstances.forEach((instance, index) => {
            const age = Math.round((now - instance.timestamp) / 1000);
            console.log(`  ${index + 1}. ${instance.id} (${age}초 전)`);
        });
        
        console.log('🔄 실행 중인 모니터링:');
        if (this.activeIntervals.size === 0) {
            console.log('  (실행 중인 모니터링 없음)');
        } else {
            for (let [id, intervalId] of this.activeIntervals) {
                const monitor = this.monitors.find(m => m.id === id);
                console.log(`  - ${monitor ? monitor.name : 'Unknown'} (ID: ${id}, Interval: ${intervalId})`);
            }
        }
        
        return {
            instanceId: this.instanceId,
            isMaster: this.wasMaster,
            activeIntervals: this.activeIntervals.size,
            totalInstances: activeInstances.length,
            instances: activeInstances
        };
    }

    // 2년 지난 오래된 데이터만 정리
    cleanupOldResults() {
        const initialCount = this.results.length;
        const twoYearsAgo = new Date();
        twoYearsAgo.setFullYear(twoYearsAgo.getFullYear() - 2);
        
        this.results = this.results.filter(r => 
            new Date(r.timestamp) > twoYearsAgo
        );

        // 메모리 절약을 위해 최대 10000개까지만 유지
        if (this.results.length > 10000) {
            this.results = this.results.slice(0, 10000);
        }

        // 데이터가 변경된 경우에만 localStorage 업데이트
        if (initialCount !== this.results.length) {
            localStorage.setItem('apiMonitorResults', JSON.stringify(this.results));
            console.log(`🗑️ 오래된 데이터 정리: ${initialCount}개 → ${this.results.length}개 (${initialCount - this.results.length}개 삭제)`);
        } else {
            console.log(`✅ 데이터 정리 완료: ${this.results.length}개 유지 (삭제 대상 없음)`);
        }
    }

    initializeEventListeners() {
        // 모니터링 추가 버튼
        document.getElementById('addMonitorBtn').addEventListener('click', () => {
            this.showAddMonitorModal();
        });

        // 모달 닫기
        document.querySelectorAll('.close-modal').forEach(btn => {
            btn.addEventListener('click', () => {
                this.hideAddMonitorModal();
            });
        });

        // 모달 외부 클릭 시 닫기
        document.getElementById('addMonitorModal').addEventListener('click', (e) => {
            if (e.target === e.currentTarget) {
                this.hideAddMonitorModal();
            }
        });

        // 모니터링 저장 버튼
        document.getElementById('saveMonitorBtn').addEventListener('click', () => {
            this.saveMonitor();
        });

        // Edit 모달 관련 이벤트
        document.querySelectorAll('#editMonitorModal .close-modal').forEach(btn => {
            btn.addEventListener('click', () => {
                this.hideEditMonitorModal();
            });
        });

        // Edit 모달 외부 클릭 시 닫기
        document.getElementById('editMonitorModal').addEventListener('click', (e) => {
            if (e.target === e.currentTarget) {
                this.hideEditMonitorModal();
            }
        });

        // 모니터링 업데이트 버튼
        document.getElementById('updateMonitorBtn').addEventListener('click', () => {
            this.updateMonitor();
        });

        // 대시보드 필터링 버튼들
        document.getElementById('showAllBtn').addEventListener('click', () => {
            this.showAllResults();
        });

        document.getElementById('showSuccessBtn').addEventListener('click', () => {
            this.showSuccessOnly();
        });

        document.getElementById('showFailuresBtn').addEventListener('click', () => {
            this.showFailuresOnly();
        });

        // 모니터 필터 이벤트 리스너
        const monitorFilter = document.getElementById('monitorFilter');
        if (monitorFilter) {
            monitorFilter.addEventListener('change', () => {
                console.log('🔍 모니터 필터 변경:', monitorFilter.value);
                this.updateFilteredResults();
            });
        }

        // 시간 범위 선택 이벤트 리스너
        const timeRangeSelect = document.getElementById('timeRange');
        const refreshBtn = document.getElementById('refreshDashboard');
        
        if (timeRangeSelect) {
            // 저장된 시간 범위 설정 복원 (기본값: 1시간)
            const savedTimeRange = localStorage.getItem('dashboardTimeRange') || '1';
            timeRangeSelect.value = savedTimeRange;
            
            timeRangeSelect.addEventListener('change', () => {
                console.log('⏰ 시간 범위 변경:', timeRangeSelect.value + '시간');
                
                // 선택된 시간 범위 저장
                localStorage.setItem('dashboardTimeRange', timeRangeSelect.value);
                
                // 시간 범위 변경 시 현재 시간으로 리셋
                this.timeOffset = 0;
                this.updateTimeNavigation();
                
                if (typeof updateDashboard === 'function') {
                    updateDashboard();
                }
            });
        }
        
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => {
                console.log('🔄 대시보드 새로고침 버튼 클릭');
                if (typeof updateDashboard === 'function') {
                    updateDashboard();
                }
            });
        }

        // 시간 네비게이션 버튼 이벤트 리스너
        const prevTimeBtn = document.getElementById('prevTimeRange');
        const nextTimeBtn = document.getElementById('nextTimeRange');
        const resetTimeBtn = document.getElementById('resetToNow');
        
        if (prevTimeBtn) {
            prevTimeBtn.addEventListener('click', () => {
                this.navigateToPrevious();
            });
        }
        
        if (nextTimeBtn) {
            nextTimeBtn.addEventListener('click', () => {
                this.navigateToNext();
            });
        }
        
        if (resetTimeBtn) {
            resetTimeBtn.addEventListener('click', () => {
                this.resetToCurrentTime();
            });
        }

        // 초기 시간 설정
        this.updateTimeNavigation();
        
        // 페이지 종료 시 정리 작업
        this.setupCleanupHandlers();
    }

    // 시간 입력 필드 24시간 포맷 강제 설정
    setupTimeInputs() {
        const startTimeInput = document.getElementById('startTime');
        const endTimeInput = document.getElementById('endTime');
        
        [startTimeInput, endTimeInput].forEach(input => {
            if (input) {
                // 언어 설정 강제
                input.setAttribute('lang', 'ko-KR');
                
                // 24시간 포맷 강제를 위한 이벤트 리스너
                input.addEventListener('input', () => {
                    // 입력값이 변경될 때마다 24시간 포맷 확인
                    this.enforceTimeFormat(input);
                });
                
                // 포커스 시에도 포맷 확인
                input.addEventListener('focus', () => {
                    this.enforceTimeFormat(input);
                });
                
                // 블러 시에도 포맷 확인
                input.addEventListener('blur', () => {
                    this.enforceTimeFormat(input);
                });
            }
        });
        
        console.log('⏰ 24시간 포맷 강제 설정 완료');
    }

    // 시간 포맷 강제 적용
    enforceTimeFormat(input) {
        if (!input.value) return;
        
        try {
            const date = new Date(input.value);
            if (!isNaN(date.getTime())) {
                // 24시간 포맷으로 재설정
                const formatted = this.formatDateTimeLocal(date);
                if (input.value !== formatted) {
                    input.value = formatted;
                    console.log('⏰ 시간 포맷 자동 수정:', formatted);
                }
            }
        } catch (e) {
            console.warn('⚠️ 시간 포맷 수정 실패:', e);
        }
    }

    showAddMonitorModal() {
        document.getElementById('addMonitorModal').classList.add('show');
        // 기존 Tester의 현재 값으로 초기화
        if (typeof apiTester !== 'undefined') {
            const currentUrl = document.getElementById('apiUrl').value;
            const currentMethod = document.getElementById('httpMethod').value;
            
            if (currentUrl) {
                document.getElementById('monitorUrl').value = currentUrl;
            }
            document.getElementById('monitorMethod').value = currentMethod;
        }
        // 실행위치 옵션 업데이트
        this.updateExecutionLocationOptions('monitorExecutionLocation');
    }

    // 히스토리 데이터로 모달 열기 (새로운 함수)
    showAddMonitorModalWithData(historyItem) {
        document.getElementById('addMonitorModal').classList.add('show');
        
        // 히스토리 데이터로 폼 채우기
        document.getElementById('monitorName').value = `${historyItem.method} ${historyItem.url.split('?')[0]} 모니터링`;
        document.getElementById('monitorUrl').value = historyItem.url;
        document.getElementById('monitorMethod').value = historyItem.method;
        
        // Headers 설정
        if (historyItem.headers) {
            document.getElementById('monitorHeaders').value = JSON.stringify(historyItem.headers, null, 2);
        }
        
        // Body 설정
        if (historyItem.body && typeof historyItem.body === 'string') {
            document.getElementById('monitorBody').value = historyItem.body;
        }
        
        // 기본 주기는 5분으로 설정
        document.getElementById('monitorInterval').value = '5';
        
        // 실행위치 옵션 업데이트
        this.updateExecutionLocationOptions('monitorExecutionLocation');
        
        console.log('히스토리에서 모니터링 모달 열기:', historyItem);
    }

    hideAddMonitorModal() {
        document.getElementById('addMonitorModal').classList.remove('show');
        this.clearModalForm();
    }

    clearModalForm() {
        document.getElementById('monitorName').value = '';
        document.getElementById('monitorUrl').value = '';
        document.getElementById('monitorMethod').value = 'GET';
        document.getElementById('monitorInterval').value = '5';
        document.getElementById('monitorExecutionLocation').value = 'browser';
        document.getElementById('monitorHeaders').value = '';
        document.getElementById('monitorBody').value = '';
    }

    // 실행위치 옵션 업데이트
    async updateExecutionLocationOptions(selectId) {
        const select = document.getElementById(selectId);
        if (!select) return;

        // 기존 옵션을 제거하고 브라우저 옵션만 남김
        select.innerHTML = '<option value="browser">브라우저</option>';

        try {
            // 에이전트 목록 가져오기
            const response = await fetch('/api/agents');
            if (response.ok) {
                const data = await response.json();
                const agents = data.agents || [];

                // 온라인 에이전트만 옵션에 추가
                const onlineAgents = agents.filter(agent => agent.status === 'healthy');
                onlineAgents.forEach(agent => {
                    const option = document.createElement('option');
                    option.value = agent.agentId;
                    option.textContent = `${agent.agentName} (${agent.systemInfo?.hostname || 'Unknown'})`;
                    select.appendChild(option);
                });

                console.log(`✅ 실행위치 옵션 업데이트: 브라우저 + ${onlineAgents.length}개 에이전트`);
            }
        } catch (error) {
            console.error('에이전트 목록 로드 실패:', error);
        }
    }

    saveMonitor() {
        const name = document.getElementById('monitorName').value.trim();
        const url = document.getElementById('monitorUrl').value.trim();
        const method = document.getElementById('monitorMethod').value;
        const interval = parseFloat(document.getElementById('monitorInterval').value);
        const executionLocation = document.getElementById('monitorExecutionLocation').value;
        const headersText = document.getElementById('monitorHeaders').value.trim();
        const body = document.getElementById('monitorBody').value.trim();

        // 유효성 검사
        if (!name || !url) {
            alert('모니터링 이름과 URL을 입력해주세요.');
            return;
        }

        let headers = {};
        if (headersText) {
            try {
                headers = JSON.parse(headersText);
            } catch (e) {
                alert('Headers는 유효한 JSON 형식이어야 합니다.');
                return;
            }
        }

        const monitor = {
            id: Date.now().toString(),
            name,
            url,
            method,
            interval,
            executionLocation,
            headers,
            body: body || null,
            active: true,
            created: new Date().toISOString(),
            lastCheck: null,
            status: 'waiting'
        };

        this.monitors.push(monitor);
        this.saveMonitors();
        this.loadMonitors();
        this.hideAddMonitorModal();
        
        // 마스터 인스턴스만 실제 모니터링 실행
        if (this.isMasterInstance()) {
            this.startMonitor(monitor);
            console.log('✅ 새 모니터링 추가 및 시작:', monitor);
        } else {
            console.log('✅ 새 모니터링 추가 (마스터 인스턴스에서 실행됨):', monitor);
        }
        
        // 3초 후 상태 확인
        setTimeout(() => {
            console.log('🔍 3초 후 모니터링 상태 확인:');
            const isRunning = this.activeIntervals.has(monitor.id);
            console.log(`⏰ Interval 등록됨: ${isRunning}`);
            console.log(`📊 활성 Interval 수: ${this.activeIntervals.size}`);
            
            if (!isRunning) {
                console.error('❌ 모니터링이 시작되지 않았습니다! 수동 재시작 시도...');
                this.startMonitor(monitor);
            }
        }, 3000);
    }

    saveMonitors() {
        localStorage.setItem('apiMonitors', JSON.stringify(this.monitors));
    }

    // 활성 모니터링 복원 (페이지 로드 시)
    restoreActiveMonitors() {
        console.log('🔄 활성 모니터링 복원 시작...');
        console.log(`📊 복원 전 활성 interval 수: ${this.activeIntervals.size}`);
        
        // 기존 모든 interval 정리 (중복 방지)
        for (let [id, intervalId] of this.activeIntervals) {
            clearInterval(intervalId);
            console.log(`🧹 기존 interval 정리: ${id} (Interval ID: ${intervalId})`);
        }
        this.activeIntervals.clear();
        
        console.log(`📊 정리 후 활성 interval 수: ${this.activeIntervals.size}`);
        
        // 마스터 인스턴스 확인 (약간의 지연 후)
        setTimeout(() => {
            const isMaster = this.isMasterInstance();
            this.wasMaster = isMaster; // 초기 마스터 상태 설정
            
            if (!isMaster) {
                console.log('🙇‍♂️ 슬레이브 인스턴스이므로 모니터링 실행을 건너뜁니다.');
                return;
            }
            
            const activeMonitors = this.monitors.filter(m => m.active);
            console.log(`👑 마스터 인스턴스에서 활성 모니터링 복원: ${activeMonitors.length}개`);
            
            activeMonitors.forEach(monitor => {
                console.log(`▶️ 모니터링 복원: ${monitor.name} (${monitor.interval}분마다)`);
                this.startMonitor(monitor);
            });
            
            console.log('✅ 마스터 인스턴스 모니터링 복원 완료');
            console.log(`📊 복원 후 활성 interval 수: ${this.activeIntervals.size}`);
        }, 1000); // 1초 지연으로 다른 인스턴스들이 등록될 시간 제공
    }

    loadMonitors() {
        const container = document.getElementById('monitorList');
        const noMonitors = container.querySelector('.no-monitors');
        
        if (this.monitors.length === 0) {
            if (noMonitors) noMonitors.style.display = 'block';
            return;
        }

        if (noMonitors) noMonitors.style.display = 'none';

        const monitorsHTML = this.monitors.map(monitor => `
            <div class="monitor-item ${monitor.active ? 'active' : 'inactive'}">
                <div class="monitor-item-header">
                    <div class="monitor-info">
                        <div class="monitor-title">
                            <div class="toggle-switch ${monitor.active ? 'active' : ''}" 
                                 onclick="apiMonitor.toggleMonitor('${monitor.id}')">
                            </div>
                            <h4>${monitor.name}</h4>
                        </div>
                        <p>${monitor.method} ${monitor.url}</p>
                    </div>
                    <div class="monitor-controls">
                        <button onclick="apiMonitor.editMonitor('${monitor.id}')" 
                                class="edit-button">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button onclick="apiMonitor.deleteMonitor('${monitor.id}')" 
                                class="remove-button">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
                <div class="monitor-status">
                    <div class="status-left">
                        <span class="monitor-interval">
                            <i class="fas fa-clock"></i>
                            ${monitor.interval >= 1 ? monitor.interval + '분마다' : (monitor.interval * 60) + '초마다'}
                        </span>
                    </div>
                    <div class="status-right">
                        ${monitor.lastCheck ? `<span class="last-check">마지막: ${new Date(monitor.lastCheck).toLocaleTimeString('ko-KR', { hour12: false })}</span>` : '<span class="last-check">아직 실행 안됨</span>'}
                        <span class="status-badge ${monitor.status}">
                            ${this.getStatusText(monitor.status)}
                        </span>
                    </div>
                </div>
            </div>
        `).join('');

        // 기존 모니터링 카드들을 제거하고 새로 추가
        const existingItems = container.querySelectorAll('.monitor-item');
        existingItems.forEach(item => item.remove());
        
        container.insertAdjacentHTML('beforeend', monitorsHTML);
        
        // 모니터 필터 옵션 업데이트
        this.updateMonitorFilterOptions();
    }

    getStatusText(status) {
        const statusMap = {
            'waiting': '대기중',
            'running': '실행중',
            'success': '성공',
            'error': '실패'
        };
        return statusMap[status] || status;
    }

    // 모니터 필터 옵션 업데이트
    updateMonitorFilterOptions() {
        const monitorFilter = document.getElementById('monitorFilter');
        if (!monitorFilter) return;

        // 현재 선택된 값 저장
        const currentValue = monitorFilter.value;
        
        // 옵션 초기화
        monitorFilter.innerHTML = '<option value="">전체 모니터</option>';
        
        // 모니터 목록에서 옵션 생성
        this.monitors.forEach(monitor => {
            const option = document.createElement('option');
            option.value = monitor.id;
            option.textContent = monitor.name;
            monitorFilter.appendChild(option);
        });
        
        // 이전 선택값이 여전히 유효하면 복원
        if (currentValue && this.monitors.find(m => m.id === currentValue)) {
            monitorFilter.value = currentValue;
        }
        
        console.log(`🔍 모니터 필터 옵션 업데이트: ${this.monitors.length}개 모니터`);
    }

        toggleMonitor(id) {
        const monitor = this.monitors.find(m => m.id === id);
        if (!monitor) {
            console.error(`❌ 토글할 모니터를 찾을 수 없음: ${id}`);
            return;
        }

        const wasActive = monitor.active;
        monitor.active = !monitor.active;
        
        console.log(`🔄 모니터링 토글: ${monitor.name} (${wasActive ? 'ON' : 'OFF'} → ${monitor.active ? 'ON' : 'OFF'})`);
        
        if (monitor.active) {
            console.log(`▶️ 모니터링 시작 요청: ${monitor.name} (${monitor.interval}분 간격)`);
            
            // 마스터 인스턴스만 실제 모니터링 실행
            if (this.isMasterInstance()) {
                this.startMonitor(monitor);
            } else {
                console.log(`🙇‍♂️ 슬레이브 인스턴스이므로 실제 모니터링은 마스터에서 실행됩니다.`);
            }
        } else {
            console.log(`⏸️ 모니터링 중지 요청: ${monitor.name}`);
            this.stopMonitor(id);
        }
        
        this.saveMonitors();
        this.loadMonitors();
    }

    startMonitor(monitor) {
        // 기존 interval 확실히 정리
        if (this.activeIntervals.has(monitor.id)) {
            const oldIntervalId = this.activeIntervals.get(monitor.id);
            clearInterval(oldIntervalId);
            this.activeIntervals.delete(monitor.id);
            console.log(`🔄 기존 모니터링 중지: ${monitor.name} (Old ID: ${oldIntervalId})`);
        }

        const intervalMs = monitor.interval * 60 * 1000; // 분을 밀리초로 변환
        console.log(`⏰ 모니터링 시작: ${monitor.name} (${monitor.interval}분 = ${intervalMs}ms 간격)`);
        console.log(`📊 현재 활성 모니터링 수: ${this.activeIntervals.size}`);
        
        // 즉시 한 번 실행
        console.log(`🚀 첫 번째 체크 실행: ${monitor.name}`);
        this.runMonitorCheck(monitor);
        
        // 주기적 실행 설정
        const intervalId = setInterval(() => {
            console.log(`⏰ [${new Date().toLocaleTimeString('ko-KR', { hour12: false })}] 주기적 체크 실행: ${monitor.name} (${monitor.interval}분 간격)`);
            this.runMonitorCheck(monitor);
        }, intervalMs);
        
        this.activeIntervals.set(monitor.id, intervalId);
        console.log(`✅ 모니터링 등록 완료: ${monitor.name} (New ID: ${intervalId})`);
        console.log(`📊 등록 후 활성 모니터링 수: ${this.activeIntervals.size}`);
        
        // 중복 실행 방지를 위한 추가 확인
        console.log(`🔍 현재 활성 모니터링 목록:`);
        for (let [id, intId] of this.activeIntervals) {
            const mon = this.monitors.find(m => m.id === id);
            console.log(`  - ID: ${id}, Interval ID: ${intId}, Name: ${mon ? mon.name : 'Unknown'}, Interval: ${mon ? mon.interval : 'Unknown'}분`);
        }
    }

    stopMonitor(id) {
        if (this.activeIntervals.has(id)) {
            const intervalId = this.activeIntervals.get(id);
            clearInterval(intervalId);
            this.activeIntervals.delete(id);
            const monitor = this.monitors.find(m => m.id === id);
            console.log(`🛑 모니터링 중지: ${monitor ? monitor.name : 'Unknown'} (ID: ${id}, Interval ID: ${intervalId})`);
            console.log(`📊 중지 후 활성 모니터링 수: ${this.activeIntervals.size}`);
        } else {
            console.log(`⚠️ 중지할 모니터링을 찾을 수 없음: ${id}`);
        }
    }

    async runMonitorCheck(monitor, isRetry = false, retryCount = 0) {
        const startTime = Date.now();
        monitor.status = 'running';
        monitor.lastCheck = new Date().toISOString();
        
        const retryInfo = isRetry ? ` (재시도 ${retryCount}/1)` : '';
        console.log(`🚀 [${new Date().toLocaleTimeString('ko-KR', { hour12: false })}] 모니터링 체크 시작: ${monitor.name}${retryInfo}`);
        console.log(`📍 URL: ${monitor.url}`);
        console.log(`⚙️ Method: ${monitor.method}`);
        
        try {
            // URL 검증 및 프록시 처리
            let requestUrl = monitor.url;
            console.log(`📋 원본 URL: ${requestUrl}`);
            
            if (!requestUrl.startsWith('http://localhost:3000/api-proxy/')) {
                // 외부 URL인 경우 프록시를 통해 요청
                requestUrl = `http://localhost:3000/api-proxy/${encodeURIComponent(monitor.url)}`;
                console.log(`🔗 프록시 URL 생성: ${requestUrl}`);
            } else {
                console.log(`🔗 이미 프록시 URL: ${requestUrl}`);
            }

            const requestOptions = {
                method: monitor.method,
                headers: {
                    'Content-Type': 'application/json',
                    ...monitor.headers
                }
            };

            if (monitor.body && ['POST', 'PUT', 'PATCH'].includes(monitor.method)) {
                requestOptions.body = monitor.body;
            }

            const response = await fetch(requestUrl, requestOptions);
            const responseTime = Date.now() - startTime;
            const responseText = await response.text();
            
            // 응답 헤더 추출
            const responseHeaders = {};
            response.headers.forEach((value, key) => {
                responseHeaders[key] = value;
            });

            const result = {
                id: Date.now().toString(),
                monitorId: monitor.id,
                monitorName: monitor.name,
                timestamp: new Date().toISOString(),
                status: response.ok ? 'success' : 'error',
                statusCode: response.status,
                statusText: response.statusText,
                responseTime,
                message: response.ok ? 'OK' : `HTTP ${response.status} ${response.statusText}`,
                responseSize: new Blob([responseText]).size,
                responseBody: responseText,
                responseHeaders: responseHeaders,
                isRetry: isRetry,
                retryCount: isRetry ? retryCount : 0,
                executionLocation: '브라우저'  // 브라우저에서 실행된 경우
            };

            // 성공하거나 4xx 에러인 경우 (클라이언트 오류)는 재시도하지 않음
            if (response.ok || (response.status >= 400 && response.status < 500)) {
                monitor.status = response.ok ? 'success' : 'error';
                this.addResult(result);
                console.log(`✅ 모니터링 체크 완료: ${monitor.name} - ${result.status} (${responseTime}ms)${retryInfo}`);
            } else {
                // 5xx 서버 오류인 경우 재시도 로직 실행
                monitor.status = 'error';
                this.addResult(result);
                
                if (!isRetry && retryCount < 1) {
                    console.log(`⚠️ 서버 오류 발생, 3초 후 재시도: ${monitor.name} (${response.status})`);
                    setTimeout(() => {
                        this.runMonitorCheck(monitor, true, retryCount + 1);
                    }, 3000); // 3초 후 재시도
                } else {
                    console.log(`❌ 모니터링 체크 실패 (재시도 완료): ${monitor.name} - ${result.status} (${responseTime}ms)`);
                }
            }

        } catch (error) {
            const responseTime = Date.now() - startTime;
            const errorBody = `Error: ${error.message}\n\nThis might be due to:\n- CORS policy restrictions\n- Network connectivity issues\n- Invalid URL\n- Server not responding`;
            
            const result = {
                id: Date.now().toString(),
                monitorId: monitor.id,
                monitorName: monitor.name,
                timestamp: new Date().toISOString(),
                status: 'error',
                statusCode: 0,
                statusText: 'Network Error',
                responseTime,
                message: error.message,
                responseSize: new Blob([errorBody]).size,
                responseBody: errorBody,
                responseHeaders: {},
                isRetry: isRetry,
                retryCount: isRetry ? retryCount : 0,
                executionLocation: '브라우저'  // 브라우저에서 실행된 경우
            };

            monitor.status = 'error';
            this.addResult(result);
            
            // 네트워크 오류인 경우에도 재시도 로직 실행
            if (!isRetry && retryCount < 1) {
                console.log(`⚠️ 네트워크 오류 발생, 3초 후 재시도: ${monitor.name} (${error.message})`);
                setTimeout(() => {
                    this.runMonitorCheck(monitor, true, retryCount + 1);
                }, 3000); // 3초 후 재시도
            } else {
                console.error(`❌ 모니터링 체크 실패 (재시도 완료): ${monitor.name} - ${error.message}${retryInfo}`);
            }
        }

        this.saveMonitors();
        this.loadMonitors();
    }

    addResult(result) {
        console.log('💾 결과 저장:', result.monitorName, result.status, result.responseTime + 'ms');
        this.results.unshift(result);
        
        // 2년 후 데이터 자동 삭제
        const twoYearsAgo = new Date();
        twoYearsAgo.setFullYear(twoYearsAgo.getFullYear() - 2);
        
        this.results = this.results.filter(r => 
            new Date(r.timestamp) > twoYearsAgo
        );

        // 메모리 절약을 위해 최대 10000개까지만 저장
        if (this.results.length > 10000) {
            this.results = this.results.slice(0, 10000);
        }

        localStorage.setItem('apiMonitorResults', JSON.stringify(this.results));
        console.log(`📂 총 결과 개수: ${this.results.length}`);
        
        // 결과 저장 후 항상 대시보드 업데이트 (실시간 반영)
        if (typeof updateDashboard === 'function') {
            console.log('🔄 결과 저장 후 대시보드 업데이트 호출');
            updateDashboard();
        } else {
            console.error('❌ updateDashboard 함수를 찾을 수 없습니다');
        }
    }

    deleteMonitor(id) {
        if (confirm('이 모니터링을 삭제하시겠습니까?')) {
            this.stopMonitor(id);
            this.monitors = this.monitors.filter(m => m.id !== id);
            this.saveMonitors();
            this.loadMonitors();
            
            // 해당 모니터링의 결과도 삭제
            this.results = this.results.filter(r => r.monitorId !== id);
            localStorage.setItem('apiMonitorResults', JSON.stringify(this.results));
        }
    }

    editMonitor(id) {
        const monitor = this.monitors.find(m => m.id === id);
        if (!monitor) return;

        this.currentEditId = id;
        this.showEditMonitorModal(monitor);
    }

    showEditMonitorModal(monitor) {
        // 실행위치 옵션 업데이트
        this.updateExecutionLocationOptions('editMonitorExecutionLocation');
        
        // 기존 값으로 폼 채우기
        document.getElementById('editMonitorName').value = monitor.name;
        document.getElementById('editMonitorUrl').value = monitor.url;
        document.getElementById('editMonitorMethod').value = monitor.method;
        document.getElementById('editMonitorInterval').value = monitor.interval;
        document.getElementById('editMonitorExecutionLocation').value = monitor.executionLocation || 'browser';
        document.getElementById('editMonitorHeaders').value = monitor.headers ? JSON.stringify(monitor.headers, null, 2) : '';
        document.getElementById('editMonitorBody').value = monitor.body || '';

        document.getElementById('editMonitorModal').classList.add('show');
    }

    hideEditMonitorModal() {
        document.getElementById('editMonitorModal').classList.remove('show');
        this.currentEditId = null;
    }

    updateMonitor() {
        if (!this.currentEditId) return;

        const name = document.getElementById('editMonitorName').value.trim();
        const url = document.getElementById('editMonitorUrl').value.trim();
        const method = document.getElementById('editMonitorMethod').value;
        const interval = parseFloat(document.getElementById('editMonitorInterval').value);
        const executionLocation = document.getElementById('editMonitorExecutionLocation').value;
        const headersText = document.getElementById('editMonitorHeaders').value.trim();
        const body = document.getElementById('editMonitorBody').value.trim();

        // 유효성 검사
        if (!name || !url) {
            alert('모니터링 이름과 URL을 입력해주세요.');
            return;
        }

        let headers = {};
        if (headersText) {
            try {
                headers = JSON.parse(headersText);
            } catch (e) {
                alert('Headers는 유효한 JSON 형식이어야 합니다.');
                return;
            }
        }

        const monitor = this.monitors.find(m => m.id === this.currentEditId);
        if (!monitor) return;

        // 모니터링이 활성화되어 있으면 일시 중지
        const wasActive = monitor.active;
        if (wasActive) {
            this.stopMonitor(this.currentEditId);
        }

        // 모니터링 정보 업데이트
        monitor.name = name;
        monitor.url = url;
        monitor.method = method;
        monitor.interval = interval;
        monitor.executionLocation = executionLocation;
        monitor.headers = headers;
        monitor.body = body || null;

        this.saveMonitors();
        this.loadMonitors();
        this.hideEditMonitorModal();

        // 이전에 활성화되어 있었다면 다시 시작
        if (wasActive) {
            this.startMonitor(monitor);
        }

        console.log('✅ 모니터링 수정 완료:', monitor);
    }

    // 전체 결과 표시
    showAllResults() {
        this.currentFilter = 'all';
        this.updateFilterButtons();
        this.updateFilteredResults();
    }

    // 성공만 표시
    showSuccessOnly() {
        this.currentFilter = 'success';
        this.updateFilterButtons();
        this.updateFilteredResults();
    }

    // 실패만 표시
    showFailuresOnly() {
        this.currentFilter = 'failures';
        this.updateFilterButtons();
        this.updateFilteredResults();
    }

    // 필터 버튼 상태 업데이트
    updateFilterButtons() {
        const showAllBtn = document.getElementById('showAllBtn');
        const showSuccessBtn = document.getElementById('showSuccessBtn');
        const showFailuresBtn = document.getElementById('showFailuresBtn');
        
        // 모든 버튼에서 active 클래스 제거
        showAllBtn?.classList.remove('active');
        showSuccessBtn?.classList.remove('active');
        showFailuresBtn?.classList.remove('active');
        
        // 현재 필터에 따라 active 클래스 추가
        if (this.currentFilter === 'all') {
            showAllBtn?.classList.add('active');
        } else if (this.currentFilter === 'success') {
            showSuccessBtn?.classList.add('active');
        } else if (this.currentFilter === 'failures') {
            showFailuresBtn?.classList.add('active');
        }
    }

    // 필터링된 결과 업데이트
    updateFilteredResults() {
        // 시간 범위에 따라 결과 필터링
        let timeFilteredResults = getTimeFilteredResults(this.results);
        
        // 모니터 필터 적용
        const monitorFilter = document.getElementById('monitorFilter');
        const selectedMonitorId = monitorFilter ? monitorFilter.value : '';
        
        if (selectedMonitorId) {
            timeFilteredResults = timeFilteredResults.filter(r => r.monitorId === selectedMonitorId);
        }
        
        // 성공/실패 필터 적용
        let filteredResults = timeFilteredResults;
        if (this.currentFilter === 'success') {
            filteredResults = timeFilteredResults.filter(r => r.status === 'success');
        } else if (this.currentFilter === 'failures') {
            filteredResults = timeFilteredResults.filter(r => r.status === 'error');
        }
        
        // 최신 순으로 정렬하고 최대 50개까지만 표시
        const displayResults = filteredResults
            .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
            .slice(0, 50);
            
        // 항목 수 업데이트
        const resultsCount = document.getElementById('resultsCount');
        if (resultsCount) {
            resultsCount.textContent = `: ${filteredResults.length}`;
        }
        
        // 필터 정보 로그
        if (selectedMonitorId) {
            const monitorName = this.monitors.find(m => m.id === selectedMonitorId)?.name || 'Unknown';
            console.log(`🔍 필터 적용 - 모니터: ${monitorName}, 상태: ${this.currentFilter}, 결과: ${filteredResults.length}개`);
        }
            
        updateResultsTable(displayResults);
    }



    // 시간 네비게이션 메소드들
    navigateToPrevious() {
        const timeRangeSelect = document.getElementById('timeRange');
        const rangeHours = timeRangeSelect ? parseFloat(timeRangeSelect.value) : 0.5;
        const rangeDuration = rangeHours * 60 * 60 * 1000; // 시간을 밀리초로 변환
        
        // 과거로 이동
        this.timeOffset -= rangeDuration;
        this.updateTimeNavigation();
        
        console.log(`⬅️ 이전 ${rangeHours}시간 구간으로 이동 (오프셋: ${this.timeOffset / (60 * 60 * 1000)}시간)`);
        
        if (typeof updateDashboard === 'function') {
            updateDashboard();
        }
    }

    navigateToNext() {
        const timeRangeSelect = document.getElementById('timeRange');
        const rangeHours = timeRangeSelect ? parseFloat(timeRangeSelect.value) : 0.5;
        const rangeDuration = rangeHours * 60 * 60 * 1000; // 시간을 밀리초로 변환
        
        // 미래로 이동하되 현재 시간을 넘지 않도록 제한
        const newOffset = this.timeOffset + rangeDuration;
        if (newOffset <= 0) {
            this.timeOffset = newOffset;
            this.updateTimeNavigation();
            
            console.log(`➡️ 다음 ${rangeHours}시간 구간으로 이동 (오프셋: ${this.timeOffset / (60 * 60 * 1000)}시간)`);
            
            if (typeof updateDashboard === 'function') {
                updateDashboard();
            }
        } else {
            console.log('➡️ 현재 시간을 넘어서 이동할 수 없습니다');
        }
    }

    resetToCurrentTime() {
        this.timeOffset = 0;
        this.updateTimeNavigation();
        
        console.log('🏠 현재 시간으로 리셋');
        
        if (typeof updateDashboard === 'function') {
            updateDashboard();
        }
    }

    getCurrentTimeRange() {
        const timeRangeSelect = document.getElementById('timeRange');
        const rangeHours = timeRangeSelect ? parseFloat(timeRangeSelect.value) : 0.5;
        const rangeDuration = rangeHours * 60 * 60 * 1000;
        
        const now = new Date();
        const endTime = new Date(now.getTime() + this.timeOffset);
        const startTime = new Date(endTime.getTime() - rangeDuration);
        
        return { startTime, endTime };
    }

    updateTimeNavigation() {
        const timeDisplay = document.getElementById('timeDisplay');
        const { startTime, endTime } = this.getCurrentTimeRange();
        
        if (timeDisplay) {
            const formatTime = (date) => {
                const month = String(date.getMonth() + 1).padStart(2, '0');
                const day = String(date.getDate()).padStart(2, '0');
                const hours = String(date.getHours()).padStart(2, '0');
                const minutes = String(date.getMinutes()).padStart(2, '0');
                return `${month}/${day} ${hours}:${minutes}`;
            };
            
            timeDisplay.textContent = `${formatTime(startTime)} ~ ${formatTime(endTime)}`;
        }
        
        this.updateNavigationButtons();
    }

    formatDateTimeLocal(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        
        return `${year}-${month}-${day}T${hours}:${minutes}`;
    }

    validateTimeRange() {
        const { startTime, endTime } = this.getCurrentTimeRange();
        
        if (startTime && endTime && startTime >= endTime) {
            alert('시작 시간은 종료 시간보다 이전이어야 합니다.');
            return false;
        }
        
        this.updateNavigationButtons();
        return true;
    }

    updateNavigationButtons() {
        const nextTimeBtn = document.getElementById('nextTimeRange');
        const resetTimeBtn = document.getElementById('resetToNow');
        
        // 다음 버튼 상태 관리 (현재 시간일 때 비활성화)
        if (nextTimeBtn) {
            nextTimeBtn.disabled = this.timeOffset >= -60000; // 1분 이내면 비활성화
        }
        
        // 리셋 버튼 상태 관리 (현재 시간 근처일 때 숨김)
        if (resetTimeBtn) {
            resetTimeBtn.style.display = Math.abs(this.timeOffset) < 300000 ? 'none' : 'flex'; // 5분 이내면 숨김
        }
    }
}

// 선택된 시간 범위에 따라 데이터 필터링하는 함수
function getTimeFilteredResults(results) {
    if (!window.apiMonitor) {
        return results;
    }
    
    const { startTime, endTime } = window.apiMonitor.getCurrentTimeRange();
    
    return results.filter(r => {
        const timestamp = new Date(r.timestamp);
        return timestamp >= startTime && timestamp <= endTime;
    });
}

// 대시보드 업데이트 함수
function updateDashboard() {
    console.log('🔄 updateDashboard 호출됨');
    if (!window.apiMonitor) {
        console.error('❌ apiMonitor가 존재하지 않습니다');
        return;
    }
    
    const allResults = window.apiMonitor.results;
    const monitors = window.apiMonitor.monitors;
    
    // 선택된 시간 범위에 따라 결과 필터링
    const filteredResults = getTimeFilteredResults(allResults);
    const timeRangeSelect = document.getElementById('timeRange');
    const selectedHours = timeRangeSelect ? timeRangeSelect.value : '1';
    
    console.log(`📊 대시보드 업데이트: ${allResults.length}개 전체 결과 → ${filteredResults.length}개 (최근 ${selectedHours}시간) 결과, ${monitors.length}개 모니터링`);
    
    // 통계 계산 (필터링된 결과 기준)
    const successCount = filteredResults.filter(r => r.status === 'success').length;
    const errorCount = filteredResults.filter(r => r.status === 'error').length;
    const totalRequests = filteredResults.length;
    const activeMonitors = monitors.filter(m => m.active).length;
    
    const avgResponseTime = totalRequests > 0 
        ? Math.round(filteredResults.reduce((sum, r) => sum + r.responseTime, 0) / totalRequests)
        : 0;

    // DOM 요소 존재 확인
    const successCountEl = document.getElementById('successCount');
    const errorCountEl = document.getElementById('errorCount');
    const avgResponseTimeEl = document.getElementById('avgResponseTime');
    const activeMonitorsEl = document.getElementById('activeMonitors');
    
    if (!successCountEl || !errorCountEl || !avgResponseTimeEl || !activeMonitorsEl) {
        console.error('❌ 대시보드 DOM 요소들을 찾을 수 없습니다:', {
            successCount: !!successCountEl,
            errorCount: !!errorCountEl,
            avgResponseTime: !!avgResponseTimeEl,
            activeMonitors: !!activeMonitorsEl
        });
        return;
    }
    
    // 통계 업데이트
    successCountEl.textContent = successCount;
    errorCountEl.textContent = errorCount;
    avgResponseTimeEl.textContent = avgResponseTime + 'ms';
    activeMonitorsEl.textContent = activeMonitors;
    
    // 시간 단위 표시 함수
    const formatTimeRange = (hours) => {
        const value = parseFloat(hours);
        if (value < 1) {
            return Math.round(value * 60) + '분';
        } else {
            return Math.round(value) + '시간';
        }
    };
    
    console.log('📊 통계 업데이트 완료:', { successCount, errorCount, avgResponseTime, activeMonitors, timeRange: formatTimeRange(selectedHours) });

    // 테이블 제목 업데이트
    const resultsTableTitle = document.getElementById('resultsTableTitle');
    const resultsCount = document.getElementById('resultsCount');
    const resultsTimeRange = document.getElementById('resultsTimeRange');
    
    if (resultsTableTitle) {
        resultsTableTitle.textContent = '자동 테스트 결과';
    }
    
    if (resultsCount) {
        resultsCount.textContent = `: ${filteredResults.length}`;
    }
    
    if (resultsTimeRange && window.apiMonitor) {
        const { startTime, endTime } = window.apiMonitor.getCurrentTimeRange();
        if (startTime && endTime) {
            const formatTime = (date) => {
                const month = String(date.getMonth() + 1).padStart(2, '0');
                const day = String(date.getDate()).padStart(2, '0');
                const hour = String(date.getHours()).padStart(2, '0');
                const minute = String(date.getMinutes()).padStart(2, '0');
                return `${month}/${day} ${hour}:${minute}`;
            };
            resultsTimeRange.textContent = `(${formatTime(startTime)} ~ ${formatTime(endTime)})`;
        } else {
            resultsTimeRange.textContent = `(최근 ${formatTimeRange(selectedHours)})`;
        }
    }

    // 차트 업데이트 (필터링된 결과 사용)
    updateCharts(filteredResults);
    
    // 최근 결과 테이블 업데이트 (필터링 적용)
    if (window.apiMonitor && window.apiMonitor.updateFilteredResults) {
        window.apiMonitor.updateFilteredResults();
    } else {
        updateResultsTable(filteredResults.slice(0, 20)); // 최근 20개
    }
}

// 차트 업데이트
function updateCharts(results) {
    // 응답 시간 차트
    updateResponseTimeChart(results);
    
    // 성공률 차트
    updateSuccessRateChart(results);
}

// 응답 시간 차트
function updateResponseTimeChart(results) {
    const ctx = document.getElementById('responseTimeChart').getContext('2d');
    
    if (window.apiMonitor.charts.responseTime) {
        window.apiMonitor.charts.responseTime.destroy();
    }
    
    // 현재 선택된 시간 범위 가져오기
    const timeRangeSelect = document.getElementById('timeRange');
    const selectedHours = timeRangeSelect ? timeRangeSelect.value : '1';
    
    // 이미 필터링된 결과를 사용 (results는 이미 시간 범위로 필터링됨)
    const timeFilteredResults = results.slice().reverse(); // 시간 순서대로 정렬

    const labels = timeFilteredResults.map(r => 
        new Date(r.timestamp).toLocaleTimeString('ko-KR', { 
            hour: '2-digit', 
            minute: '2-digit',
            hour12: false
        })
    );
    
    const data = timeFilteredResults.map(r => r.responseTime);
    
    // 평균응답시간 계산
    const avgResponseTime = data.length > 0 
        ? Math.round(data.reduce((sum, val) => sum + val, 0) / data.length)
        : 0;
    
    // 평균값 수평선을 위한 데이터
    const avgData = new Array(data.length).fill(avgResponseTime);

    window.apiMonitor.charts.responseTime = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: `평균응답시간 (${avgResponseTime}ms)`,
                data: avgData,
                borderColor: 'rgba(255, 99, 132, 1)',
                backgroundColor: 'rgba(255, 99, 132, 0.1)',
                borderWidth: 3,
                borderDash: [8, 4],
                pointRadius: 0,
                tension: 0,
                order: 1
            }, {
                label: '응답 시간 (ms)',
                data: data,
                borderColor: 'rgb(75, 192, 192)',
                backgroundColor: 'rgba(75, 192, 192, 0.1)',
                tension: 0.1,
                order: 2
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: '응답 시간 (ms)'
                    }
                }
            }
        }
    });
}

// 성공률 차트
function updateSuccessRateChart(results) {
    const ctx = document.getElementById('successRateChart').getContext('2d');
    
    if (window.apiMonitor.charts.successRate) {
        window.apiMonitor.charts.successRate.destroy();
    }
    
    // 현재 선택된 시간 범위 가져오기
    const timeRangeSelect = document.getElementById('timeRange');
    const selectedHours = timeRangeSelect ? timeRangeSelect.value : '1';
    
    const successCount = results.filter(r => r.status === 'success').length;
    const errorCount = results.filter(r => r.status === 'error').length;
    const total = successCount + errorCount;
    
    // 성공률 계산
    const successRate = total > 0 ? Math.round((successCount / total) * 100) : 0;
    const errorRate = total > 0 ? Math.round((errorCount / total) * 100) : 0;

    window.apiMonitor.charts.successRate = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: [`성공 (${successRate}%)`, `실패 (${errorRate}%)`],
            datasets: [{
                data: [successCount, errorCount],
                backgroundColor: [
                    'rgba(75, 192, 192, 0.8)',
                    'rgba(255, 99, 132, 0.8)'
                ],
                borderColor: [
                    'rgb(75, 192, 192)',
                    'rgb(255, 99, 132)'
                ],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            cutout: '60%', // 도넛 중앙 공간 크기
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        generateLabels: function(chart) {
                            const data = chart.data;
                            const labels = data.labels;
                            const dataset = data.datasets[0];
                            
                            return labels.map((label, index) => ({
                                text: label,
                                fillStyle: dataset.backgroundColor[index],
                                strokeStyle: dataset.borderColor[index],
                                lineWidth: dataset.borderWidth
                            }));
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const value = context.parsed;
                            const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                            return `${context.label}: ${value}개 (${percentage}%)`;
                        }
                    }
                }
            }
        },
        plugins: [{
            id: 'centerText',
            beforeDraw: function(chart) {
                if (total === 0) return;
                
                const { width, height } = chart;
                const ctx = chart.ctx;
                
                ctx.restore();
                const fontSize = Math.min(width, height) / 8;
                ctx.font = `bold ${fontSize}px Arial`;
                ctx.textBaseline = 'middle';
                ctx.fillStyle = '#495057';
                
                const text = `${successRate}%`;
                const textX = Math.round((width - ctx.measureText(text).width) / 2);
                const textY = height / 2;
                
                ctx.fillText(text, textX, textY);
                
                // 성공률 라벨
                ctx.font = `${fontSize * 0.4}px Arial`;
                ctx.fillStyle = '#6c757d';
                const labelText = '성공률';
                const labelX = Math.round((width - ctx.measureText(labelText).width) / 2);
                const labelY = textY + fontSize * 0.7;
                
                ctx.fillText(labelText, labelX, labelY);
                ctx.save();
            }
        }]
    });
}

// 결과 테이블 업데이트
function updateResultsTable(results) {
    const tbody = document.getElementById('resultsTableBody');
    
    if (results.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="no-data">데이터가 없습니다.</td></tr>';
        return;
    }

    tbody.innerHTML = results.map((result, index) => {
        const date = new Date(result.timestamp);
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const hour = String(date.getHours()).padStart(2, '0');
        const minute = String(date.getMinutes()).padStart(2, '0');
        const second = String(date.getSeconds()).padStart(2, '0');
        const formattedDate = `${year}/${month}/${day} ${hour}:${minute}:${second}`;
        
        // retry 태그 생성
        const retryTag = result.isRetry ? `<span class="retry-tag">RETRY ${result.retryCount}</span>` : '';
        
        return `
        <tr class="result-row clickable-row" data-result-index="${index}">
            <td>${formattedDate} ${retryTag}</td>
            <td>${result.monitorName}</td>
            <td>
                <span class="status-badge ${result.status}">
                    ${result.status === 'success' ? '성공' : '실패'}
                </span>
            </td>
            <td>${result.responseTime}ms</td>
            <td>${result.executionLocation || '브라우저'}</td>
            <td>${result.message}</td>
        </tr>
        `;
    }).join('');

    // 테이블 행 클릭 이벤트 추가
    const resultRows = tbody.querySelectorAll('.result-row');
    resultRows.forEach(row => {
        row.addEventListener('click', (e) => {
            const resultIndex = parseInt(e.currentTarget.dataset.resultIndex);
            const result = results[resultIndex];
            
            // 기존 선택된 행의 스타일 제거
            resultRows.forEach(r => r.classList.remove('selected'));
            
            // 클릭한 행에 선택 스타일 추가
            e.currentTarget.classList.add('selected');
            
            // 상세 정보 표시
            showResultDetails(result);
            
            console.log('📊 대시보드 결과 클릭:', result.monitorName, result.status);
        });
    });
}

// 결과 상세 정보를 Response 섹션에 표시
function showResultDetails(result) {
    console.log('📋 결과 상세 정보 표시:', result);
    
    // 응답 섹션 표시
    const responseSection = document.querySelector('.response-section');
    if (responseSection) {
        responseSection.style.display = 'block';
    }
    
    // 상태 코드와 텍스트 표시
    const statusCode = result.statusCode || (result.status === 'success' ? 200 : 0);
    const statusText = result.statusText || (result.status === 'success' ? 'OK' : 'Error');
    
    document.getElementById('responseStatusCode').textContent = statusCode;
    document.getElementById('responseStatusText').textContent = statusText;
    
    // 응답 시간과 크기 표시
    document.getElementById('responseTime').textContent = `${result.responseTime}ms`;
    document.getElementById('responseSize').textContent = result.responseSize ? `${result.responseSize} bytes` : '-';
    
    // 응답 본문 표시
    const responseBody = result.responseBody || result.message || '응답 본문이 없습니다.';
    document.getElementById('responseBody').textContent = responseBody;
    
    // 응답 헤더 표시
    const responseHeaders = result.responseHeaders || {};
    const headersText = Object.keys(responseHeaders).length > 0 
        ? JSON.stringify(responseHeaders, null, 2)
        : '응답 헤더가 없습니다.';
    document.getElementById('responseHeaders').textContent = headersText;
    
    // 응답 섹션으로 스크롤
    responseSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// 전역 변수
window.apiMonitor = null;

// 모니터링 시스템 초기화
document.addEventListener('DOMContentLoaded', () => {
    // 기존 초기화가 완료된 후 모니터링 시스템 초기화
    setTimeout(() => {
        window.apiMonitor = new APIMonitor();
        console.log('API Monitor 초기화 완료!');
        
        // 개발자용 디버깅 함수 전역 등록
        window.debugMonitor = () => {
            console.log('=== 모니터링 상태 디버깅 ===');
            console.log('📊 총 모니터링:', window.apiMonitor.monitors.length);
            console.log('▶️ 활성 모니터링:', window.apiMonitor.monitors.filter(m => m.active).length);
            console.log('⏰ 실행 중인 interval:', window.apiMonitor.activeIntervals.size);
            console.log('📈 결과 개수:', window.apiMonitor.results.length);
            
            window.apiMonitor.monitors.forEach(monitor => {
                const status = monitor.active ? '🟢 활성' : '🔴 비활성';
                const running = window.apiMonitor.activeIntervals.has(monitor.id) ? '⏰ 실행중' : '⏸️ 중지됨';
                console.log(`${status} ${running} | ${monitor.name} (${monitor.interval}분)`);
            });
            
            console.log('=== 최근 결과 5개 ===');
            window.apiMonitor.results.slice(0, 5).forEach((result, i) => {
                console.log(`${i+1}. ${result.monitorName} - ${result.status} (${result.responseTime}ms) [${new Date(result.timestamp).toLocaleTimeString('ko-KR', { hour12: false })}]`);
            });
            
            console.log('=== 콘솔에서 debugMonitor() 실행하여 상태 확인 ===');
        };
        
        // 중복 실행 방지 시스템 디버깅 함수
        window.debugInstances = () => {
            return window.apiMonitor.getDebugInfo();
        };
        
        // 모든 인스턴스 정보 초기화 함수
        window.clearAllInstances = () => {
            localStorage.removeItem('apiMonitorInstances');
            console.log('🧹 모든 인스턴스 정보가 삭제되었습니다. 페이지를 새로고침하세요.');
        };
        
        // 강제로 마스터 인스턴스로 설정
        window.forceMaster = () => {
            window.apiMonitor.wasMaster = false; // 이전 상태를 false로 설정
            const instances = JSON.parse(localStorage.getItem('apiMonitorInstances') || '[]');
            const updatedInstances = instances.map(instance => {
                if (instance.id === window.apiMonitor.instanceId) {
                    return { ...instance, timestamp: Date.now() - 10 * 60 * 1000 }; // 10분 전으로 설정하여 가장 오래된 인스턴스로 만듦
                }
                return instance;
            });
            localStorage.setItem('apiMonitorInstances', JSON.stringify(updatedInstances));
            window.apiMonitor.checkMasterSuccession();
            console.log('👑 강제로 마스터 인스턴스로 설정되었습니다.');
        };
        
        // 테스트 모니터링 생성 함수
        window.createTestMonitor = () => {
            console.log('🧪 테스트 모니터링 생성 중...');
            const testMonitor = {
                id: 'test-' + Date.now(),
                name: '테스트 모니터링',
                url: 'https://jsonplaceholder.typicode.com/posts/1',
                method: 'GET',
                interval: 0.5, // 30초
                headers: {},
                body: null,
                active: true,
                created: new Date().toISOString(),
                lastCheck: null,
                status: 'waiting'
            };
            
            window.apiMonitor.monitors.push(testMonitor);
            window.apiMonitor.saveMonitors();
            window.apiMonitor.loadMonitors();
            window.apiMonitor.startMonitor(testMonitor);
            
            console.log('✅ 테스트 모니터링 생성 완료:', testMonitor.name);
            return testMonitor;
        };
        
        // 대시보드 강제 업데이트 함수
        window.forceDashboardUpdate = () => {
            console.log('🔄 대시보드 강제 업데이트...');
            if (typeof updateDashboard === 'function') {
                updateDashboard();
                console.log('✅ 대시보드 업데이트 완료');
            } else {
                console.error('❌ updateDashboard 함수를 찾을 수 없습니다');
            }
        };
        
        // 30초마다 상태 체크 (개발용)
        setInterval(() => {
            if (!window.apiMonitor) return;
            const activeCount = window.apiMonitor.monitors.filter(m => m.active).length;
            const runningCount = window.apiMonitor.activeIntervals.size;
            
            if (activeCount !== runningCount) {
                console.warn(`⚠️ 모니터링 상태 불일치! 활성: ${activeCount}, 실행중: ${runningCount}`);
                console.log('🔧 자동 복구 시도...');
                window.apiMonitor.restoreActiveMonitors();
            }
        }, 30000);
        
        // 디버깅 명령어 안내
        console.log(`
🎮 === 모니터링 디버깅 명령어 ===
📊 debugMonitor()       - 기본 모니터링 상태 확인
👥 debugInstances()     - 인스턴스 및 중복 실행 상태 확인
🧹 clearAllInstances()  - 모든 인스턴스 정보 삭제 (중복 해결)
👑 forceMaster()        - 현재 탭을 강제로 마스터로 설정
🧪 createTestMonitor()  - 테스트 모니터링 생성 (30초 간격)
🔄 forceDashboardUpdate() - 대시보드 강제 업데이트
=====================================
💡 모니터가 중복 실행되는 경우:
   1. debugInstances() 로 상태 확인
   2. clearAllInstances() 로 정리
   3. 페이지 새로고침
`);
        
    }, 100);
}); 

// === 에이전트 관리 시스템 ===
class AgentManager {
    constructor() {
        this.agents = new Map();
        this.ws = null;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.reconnectInterval = 5000;
        this.isConnecting = false;
        
        this.initializeEventListeners();
        this.connectToServer();
        
        // 30초마다 에이전트 상태 업데이트
        setInterval(() => {
            this.refreshAgentStatus();
        }, 30000);
    }
    
    initializeEventListeners() {
        // 새로고침 버튼
        document.getElementById('refreshAgentsBtn')?.addEventListener('click', () => {
            this.refreshAgentStatus();
        });
        
        // 연결 정보 보기 버튼
        document.getElementById('showAgentInfoBtn')?.addEventListener('click', () => {
            document.getElementById('agentConnectionInfo').style.display = 'block';
        });
    }
    
    connectToServer() {
        if (this.isConnecting) return;
        
        this.isConnecting = true;
        console.log('🔌 에이전트 관리 서버에 연결 중...');
        
        try {
            this.ws = new WebSocket('ws://localhost:3000/admin-ws');
            
            this.ws.onopen = () => {
                console.log('✅ 에이전트 관리 서버 연결 성공');
                this.isConnecting = false;
                this.reconnectAttempts = 0;
                
                // 관리자로 등록
                this.ws.send(JSON.stringify({
                    type: 'admin-register'
                }));
                
                this.updateConnectionStatus(true);
                this.requestAgentList();
            };
            
            this.ws.onmessage = (event) => {
                this.handleServerMessage(JSON.parse(event.data));
            };
            
            this.ws.onclose = () => {
                console.log('❌ 에이전트 관리 서버 연결 끊어짐');
                this.isConnecting = false;
                this.updateConnectionStatus(false);
                this.scheduleReconnect();
            };
            
            this.ws.onerror = (error) => {
                console.error('❌ WebSocket 연결 오류:', error);
                this.isConnecting = false;
                this.updateConnectionStatus(false);
            };
            
        } catch (error) {
            console.error('❌ WebSocket 생성 실패:', error);
            this.isConnecting = false;
            this.scheduleReconnect();
        }
    }
    
    scheduleReconnect() {
        if (this.reconnectAttempts >= this.maxReconnectAttempts) {
            console.error('❌ 최대 재연결 시도 횟수 초과');
            return;
        }
        
        this.reconnectAttempts++;
        console.log(`🔄 ${this.reconnectInterval/1000}초 후 재연결 시도... (${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
        
        setTimeout(() => {
            this.connectToServer();
        }, this.reconnectInterval);
    }
    
    handleServerMessage(message) {
        console.log('📨 서버 메시지:', message);
        
        switch (message.type) {
            case 'agent-list':
                this.updateAgentList(message.agents);
                break;
            case 'agent-connected':
                this.handleAgentConnected(message.agent);
                break;
            case 'agent-disconnected':
                this.handleAgentDisconnected(message.agentId);
                break;
            case 'monitor-assignments':
                this.updateMonitorAssignments(message.assignments);
                break;
            case 'agent-stats':
                this.updateAgentStats(message.stats);
                break;
        }
    }
    
    requestAgentList() {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({
                type: 'get-agent-list'
            }));
        }
    }
    
    refreshAgentStatus() {
        console.log('🔄 에이전트 상태 새로고침...');
        this.requestAgentList();
    }
    
    updateConnectionStatus(connected) {
        const statusElement = document.getElementById('agentStatus');
        if (statusElement) {
            const icon = statusElement.querySelector('i');
            if (connected) {
                icon.className = 'fas fa-circle text-green';
                icon.style.color = '#10b981';
            } else {
                icon.className = 'fas fa-circle text-red';
                icon.style.color = '#ef4444';
            }
        }
    }
    
    updateAgentList(agents) {
        console.log('👥 에이전트 목록 업데이트:', agents);
        
        // 에이전트 데이터 저장
        this.agents.clear();
        agents.forEach(agent => {
            this.agents.set(agent.id, agent);
        });
        
        // 온라인 에이전트 수 업데이트
        const onlineCount = agents.length;
        document.getElementById('onlineAgentsCount').textContent = onlineCount;
        
        // 에이전트 목록 UI 업데이트
        this.renderAgentList(agents);
    }
    
    renderAgentList(agents) {
        const agentsList = document.getElementById('agentsList');
        if (!agentsList) return;
        
        if (agents.length === 0) {
            agentsList.innerHTML = `
                <div class="no-agents">
                    <i class="fas fa-robot fa-3x"></i>
                    <h3>연결된 에이전트가 없습니다</h3>
                    <p>에이전트를 연결하면 모니터링 작업을 분산 처리할 수 있습니다.</p>
                    <button class="show-info-btn" onclick="document.getElementById('agentConnectionInfo').style.display='block'">
                        <i class="fas fa-info-circle"></i> 연결 방법 보기
                    </button>
                </div>
            `;
            return;
        }
        
        agentsList.innerHTML = agents.map(agent => {
            const connectedTime = new Date(agent.connectedAt);
            const uptime = this.calculateUptime(connectedTime);
            const taskCount = agent.stats?.completedTasks || 0;
            const errorCount = agent.stats?.failedTasks || 0;
            const avgResponseTime = agent.stats?.avgResponseTime || 0;
            
            return `
                <div class="agent-card" data-agent-id="${agent.id}">
                    <div class="agent-header">
                        <div class="agent-info">
                            <h4>
                                <i class="fas fa-robot"></i>
                                ${agent.name}
                                <span class="agent-status online">
                                    <i class="fas fa-circle"></i> 온라인
                                </span>
                            </h4>
                            <p class="agent-hostname">
                                <i class="fas fa-server"></i> ${agent.hostname}
                                <span class="agent-id">(${agent.id})</span>
                            </p>
                        </div>
                        <div class="agent-actions">
                            <button class="agent-action-btn" onclick="agentManager.assignMonitor('${agent.id}')" title="모니터링 할당">
                                <i class="fas fa-plus"></i>
                            </button>
                            <button class="agent-action-btn" onclick="agentManager.showAgentDetails('${agent.id}')" title="상세 정보">
                                <i class="fas fa-info-circle"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div class="agent-stats">
                        <div class="stat-item">
                            <span class="stat-label">가동시간:</span>
                            <span class="stat-value">${uptime}</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">처리한 작업:</span>
                            <span class="stat-value">${taskCount}개</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">실패:</span>
                            <span class="stat-value">${errorCount}개</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">평균 응답시간:</span>
                            <span class="stat-value">${avgResponseTime}ms</span>
                        </div>
                    </div>
                    
                    <div class="agent-load">
                        <div class="load-bar">
                            <div class="load-fill" style="width: ${((agent.currentTasks || 0) / (agent.maxConcurrentTasks || 1)) * 100}%"></div>
                        </div>
                        <span class="load-text">${agent.currentTasks || 0}/${agent.maxConcurrentTasks || 1} 작업</span>
                    </div>
                </div>
            `;
        }).join('');
    }
    
    calculateUptime(connectedTime) {
        const now = new Date();
        const diffMs = now - connectedTime;
        
        const hours = Math.floor(diffMs / (1000 * 60 * 60));
        const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
        
        if (hours > 0) {
            return `${hours}시간 ${minutes}분`;
        } else {
            return `${minutes}분`;
        }
    }
    
    handleAgentConnected(agent) {
        console.log('🤖 새 에이전트 연결:', agent.name);
        this.agents.set(agent.id, agent);
        this.refreshAgentStatus();
        
        // 알림 표시
        this.showNotification(`✅ ${agent.name} 에이전트가 연결되었습니다.`, 'success');
    }
    
    handleAgentDisconnected(agentId) {
        const agent = this.agents.get(agentId);
        if (agent) {
            console.log('❌ 에이전트 연결 끊어짐:', agent.name);
            this.agents.delete(agentId);
            this.refreshAgentStatus();
            
            // 알림 표시
            this.showNotification(`❌ ${agent.name} 에이전트 연결이 끊어졌습니다.`, 'error');
        }
    }
    
    updateMonitorAssignments(assignments) {
        console.log('📋 모니터링 할당 현황 업데이트:', assignments);
        
        const assignmentsList = document.getElementById('assignmentsList');
        const assignmentCount = document.getElementById('assignmentCount');
        
        if (!assignmentsList || !assignmentCount) return;
        
        const totalMonitors = window.apiMonitor?.monitors?.filter(m => m.active)?.length || 0;
        const assignedCount = Object.keys(assignments).length;
        
        assignmentCount.textContent = `(${assignedCount}/${totalMonitors})`;
        
        if (assignedCount === 0) {
            assignmentsList.innerHTML = `
                <div class="no-assignments">
                    <i class="fas fa-clipboard-list"></i>
                    <p>할당된 모니터링 작업이 없습니다.</p>
                </div>
            `;
            return;
        }
        
        assignmentsList.innerHTML = Object.entries(assignments).map(([monitorId, agentId]) => {
            const monitor = window.apiMonitor?.monitors?.find(m => m.id === monitorId);
            const agent = this.agents.get(agentId);
            
            if (!monitor || !agent) return '';
            
            return `
                <div class="assignment-item">
                    <div class="assignment-info">
                        <span class="monitor-name">
                            <i class="fas fa-chart-line"></i>
                            ${monitor.name}
                        </span>
                        <span class="assignment-arrow">→</span>
                        <span class="agent-name">
                            <i class="fas fa-robot"></i>
                            ${agent.name}
                        </span>
                    </div>
                    <button class="reassign-btn" onclick="agentManager.reassignMonitor('${monitorId}')" title="재할당">
                        <i class="fas fa-exchange-alt"></i>
                    </button>
                </div>
            `;
        }).join('');
    }
    
    updateAgentStats(stats) {
        console.log('📊 에이전트 통계 업데이트:', stats);
        
        document.getElementById('avgTaskTime').textContent = `${stats.avgTaskTime || 0}ms`;
        document.getElementById('completedTasks').textContent = stats.completedTasks || 0;
        document.getElementById('failedTasks').textContent = stats.failedTasks || 0;
        document.getElementById('tasksPerMinute').textContent = stats.tasksPerMinute || 0;
    }
    
    assignMonitor(agentId) {
        // 할당 가능한 모니터링 목록을 보여주는 모달 표시
        this.showAssignMonitorModal(agentId);
    }
    
    showAssignMonitorModal(agentId) {
        const agent = this.agents.get(agentId);
        if (!agent) return;
        
        const activeMonitors = window.apiMonitor?.monitors?.filter(m => m.active) || [];
        
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3><i class="fas fa-plus-circle"></i> ${agent.name}에 모니터링 할당</h3>
                    <button class="close-modal" onclick="this.closest('.modal').remove()">&times;</button>
                </div>
                <div class="modal-body">
                    ${activeMonitors.length === 0 ? `
                        <p>할당 가능한 활성 모니터링이 없습니다.</p>
                    ` : `
                        <div class="monitor-list">
                            ${activeMonitors.map(monitor => `
                                <div class="monitor-item">
                                    <input type="radio" name="selectedMonitor" value="${monitor.id}" id="monitor-${monitor.id}">
                                    <label for="monitor-${monitor.id}">
                                        <strong>${monitor.name}</strong>
                                        <div class="monitor-details">
                                            <span>${monitor.method} ${monitor.url}</span>
                                            <span>매 ${monitor.interval}분</span>
                                        </div>
                                    </label>
                                </div>
                            `).join('')}
                        </div>
                    `}
                </div>
                <div class="modal-footer">
                    <button onclick="agentManager.confirmAssignMonitor('${agentId}', this.closest('.modal'))" class="save-btn">
                        <i class="fas fa-check"></i> 할당
                    </button>
                    <button onclick="this.closest('.modal').remove()" class="cancel-btn">취소</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        modal.style.display = 'block';
    }
    
    confirmAssignMonitor(agentId, modal) {
        const selectedMonitor = modal.querySelector('input[name="selectedMonitor"]:checked');
        if (!selectedMonitor) {
            alert('모니터링을 선택해주세요.');
            return;
        }
        
        const monitorId = selectedMonitor.value;
        
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({
                type: 'assign-monitor',
                monitorId: monitorId,
                agentId: agentId
            }));
            
            modal.remove();
            this.showNotification('✅ 모니터링이 할당되었습니다.', 'success');
        } else {
            alert('서버와의 연결이 끊어졌습니다.');
        }
    }
    
    reassignMonitor(monitorId) {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({
                type: 'reassign-monitor',
                monitorId: monitorId
            }));
            
            this.showNotification('🔄 모니터링을 재할당했습니다.', 'info');
        }
    }
    
    showAgentDetails(agentId) {
        const agent = this.agents.get(agentId);
        if (!agent) return;
        
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3><i class="fas fa-robot"></i> ${agent.name} 상세 정보</h3>
                    <button class="close-modal" onclick="this.closest('.modal').remove()">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="agent-details">
                        <div class="detail-section">
                            <h4>기본 정보</h4>
                            <div class="detail-grid">
                                <div class="detail-item">
                                    <span class="detail-label">ID:</span>
                                    <span class="detail-value">${agent.id}</span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-label">호스트명:</span>
                                    <span class="detail-value">${agent.hostname}</span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-label">연결 시간:</span>
                                    <span class="detail-value">${new Date(agent.connectedAt).toLocaleString('ko-KR')}</span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-label">최대 동시 작업:</span>
                                    <span class="detail-value">${agent.maxConcurrentTasks}</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="detail-section">
                            <h4>성능 통계</h4>
                            <div class="detail-grid">
                                <div class="detail-item">
                                    <span class="detail-label">완료된 작업:</span>
                                    <span class="detail-value">${agent.stats?.completedTasks || 0}</span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-label">실패한 작업:</span>
                                    <span class="detail-value">${agent.stats?.failedTasks || 0}</span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-label">평균 응답시간:</span>
                                    <span class="detail-value">${agent.stats?.avgResponseTime || 0}ms</span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-label">성공률:</span>
                                    <span class="detail-value">${this.calculateSuccessRate(agent.stats)}%</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="detail-section">
                            <h4>기능</h4>
                            <div class="capabilities-list">
                                ${agent.capabilities?.map(cap => `
                                    <span class="capability-tag">${cap}</span>
                                `).join('') || '<span class="no-capabilities">기능 정보 없음</span>'}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button onclick="this.closest('.modal').remove()" class="cancel-btn">닫기</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        modal.style.display = 'block';
    }
    
    calculateSuccessRate(stats) {
        if (!stats) return 0;
        const total = (stats.completedTasks || 0) + (stats.failedTasks || 0);
        if (total === 0) return 0;
        return Math.round(((stats.completedTasks || 0) / total) * 100);
    }
    
    showNotification(message, type = 'info') {
        // 간단한 알림 표시
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 12px 20px;
            border-radius: 8px;
            color: white;
            font-weight: 500;
            z-index: 10000;
            animation: slideIn 0.3s ease-out;
        `;
        
        // 타입별 배경색
        const colors = {
            success: '#10b981',
            error: '#ef4444',
            warning: '#f59e0b',
            info: '#3b82f6'
        };
        notification.style.backgroundColor = colors[type] || colors.info;
        
        document.body.appendChild(notification);
        
        // 3초 후 자동 제거
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease-in';
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, 3000);
    }
}

// 전역 에이전트 매니저 인스턴스
let agentManager = null;

// 에이전트 관리 시스템 초기화 (기존 초기화 이후 실행)
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        if (document.getElementById('agents-section')) {
            agentManager = new AgentManager();
            console.log('🤖 에이전트 관리 시스템 초기화 완료');
        }
    }, 200);
});

// CSS 애니메이션 추가
const style = document.createElement('style');
style.textContent = `
@keyframes slideIn {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

@keyframes slideOut {
    from {
        transform: translateX(0);
        opacity: 1;
    }
    to {
        transform: translateX(100%);
        opacity: 0;
    }
}
`;
document.head.appendChild(style);