#!/bin/bash

# API Monitor Agent Installer
# Version: 1.0.0

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
AGENT_DIR="/opt/api-monitor-agent"
SERVICE_USER="api-monitor"
AGENT_PORT="8080"
CENTRAL_DASHBOARD=""
AGENT_NAME=""

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if running as root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        print_error "This script must be run as root (use sudo)"
        exit 1
    fi
}

# Function to detect OS
detect_os() {
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        if [ -f /etc/redhat-release ]; then
            OS="centos"
        elif [ -f /etc/debian_version ]; then
            OS="ubuntu"
        else
            OS="linux"
        fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        OS="macos"
    else
        print_error "Unsupported operating system: $OSTYPE"
        exit 1
    fi
    print_status "Detected OS: $OS"
}

# Function to install Node.js
install_nodejs() {
    print_status "Checking Node.js installation..."
    
    if command -v node &> /dev/null; then
        NODE_VERSION=$(node --version)
        print_success "Node.js is already installed: $NODE_VERSION"
        return
    fi
    
    print_status "Installing Node.js..."
    
    if [[ "$OS" == "ubuntu" ]]; then
        curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
        apt-get install -y nodejs
    elif [[ "$OS" == "centos" ]]; then
        curl -fsSL https://rpm.nodesource.com/setup_18.x | bash -
        yum install -y nodejs npm
    elif [[ "$OS" == "macos" ]]; then
        if command -v brew &> /dev/null; then
            brew install node
        else
            print_error "Please install Homebrew first or install Node.js manually"
            exit 1
        fi
    fi
    
    print_success "Node.js installed successfully"
}

# Function to create service user
create_user() {
    if id "$SERVICE_USER" &>/dev/null; then
        print_status "User $SERVICE_USER already exists"
    else
        print_status "Creating service user: $SERVICE_USER"
        useradd --system --shell /bin/false --home-dir $AGENT_DIR --create-home $SERVICE_USER
        print_success "User $SERVICE_USER created"
    fi
}

# Function to install agent files
install_agent() {
    print_status "Installing API Monitor Agent..."
    
    # Create directory
    mkdir -p $AGENT_DIR
    
    # Copy agent files
    cp -r . $AGENT_DIR/
    cd $AGENT_DIR
    
    # Install dependencies
    print_status "Installing Node.js dependencies..."
    npm install --production
    
    # Set permissions
    chown -R $SERVICE_USER:$SERVICE_USER $AGENT_DIR
    chmod +x $AGENT_DIR/agent.js
    
    print_success "Agent files installed to $AGENT_DIR"
}

# Function to create configuration file
create_config() {
    print_status "Creating configuration file..."
    
    cat > $AGENT_DIR/config.json << EOF
{
  "agentName": "$AGENT_NAME",
  "port": $AGENT_PORT,
  "centralDashboard": "$CENTRAL_DASHBOARD",
  "logLevel": "info",
  "maxConcurrentMonitors": 50,
  "healthCheckInterval": 60000,
  "reconnectInterval": 30000
}
EOF
    
    chown $SERVICE_USER:$SERVICE_USER $AGENT_DIR/config.json
    chmod 644 $AGENT_DIR/config.json
    
    print_success "Configuration file created"
}

# Function to create systemd service
create_systemd_service() {
    print_status "Creating systemd service..."
    
    cat > /etc/systemd/system/api-monitor-agent.service << EOF
[Unit]
Description=API Monitor Agent
Documentation=https://github.com/your-org/api-monitor-agent
After=network.target

[Service]
Type=simple
User=$SERVICE_USER
WorkingDirectory=$AGENT_DIR
ExecStart=/usr/bin/node $AGENT_DIR/agent.js --config $AGENT_DIR/config.json
Restart=always
RestartSec=10
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=api-monitor-agent
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF
    
    systemctl daemon-reload
    systemctl enable api-monitor-agent
    
    print_success "Systemd service created and enabled"
}

# Function to create launchd service (macOS)
create_launchd_service() {
    print_status "Creating launchd service..."
    
    cat > /Library/LaunchDaemons/com.apimonitor.agent.plist << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.apimonitor.agent</string>
    <key>ProgramArguments</key>
    <array>
        <string>/usr/local/bin/node</string>
        <string>$AGENT_DIR/agent.js</string>
        <string>--config</string>
        <string>$AGENT_DIR/config.json</string>
    </array>
    <key>WorkingDirectory</key>
    <string>$AGENT_DIR</string>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>/var/log/api-monitor-agent.log</string>
    <key>StandardErrorPath</key>
    <string>/var/log/api-monitor-agent.error.log</string>
</dict>
</plist>
EOF
    
    chown root:wheel /Library/LaunchDaemons/com.apimonitor.agent.plist
    chmod 644 /Library/LaunchDaemons/com.apimonitor.agent.plist
    
    print_success "Launchd service created"
}

# Function to create service
create_service() {
    if [[ "$OS" == "macos" ]]; then
        create_launchd_service
    else
        create_systemd_service
    fi
}

# Function to start service
start_service() {
    print_status "Starting API Monitor Agent service..."
    
    if [[ "$OS" == "macos" ]]; then
        launchctl load /Library/LaunchDaemons/com.apimonitor.agent.plist
    else
        systemctl start api-monitor-agent
    fi
    
    sleep 3
    
    # Check if service is running
    if [[ "$OS" == "macos" ]]; then
        if launchctl list | grep -q "com.apimonitor.agent"; then
            print_success "Service started successfully"
        else
            print_error "Failed to start service"
            exit 1
        fi
    else
        if systemctl is-active --quiet api-monitor-agent; then
            print_success "Service started successfully"
        else
            print_error "Failed to start service"
            systemctl status api-monitor-agent
            exit 1
        fi
    fi
}

# Function to show status
show_status() {
    echo
    print_success "🎉 API Monitor Agent installation completed!"
    echo
    echo "Configuration:"
    echo "  - Agent Name: $AGENT_NAME"
    echo "  - Port: $AGENT_PORT"
    echo "  - Central Dashboard: $CENTRAL_DASHBOARD"
    echo "  - Installation Directory: $AGENT_DIR"
    echo "  - Service User: $SERVICE_USER"
    echo
    echo "Service Management:"
    if [[ "$OS" == "macos" ]]; then
        echo "  - Start:   sudo launchctl load /Library/LaunchDaemons/com.apimonitor.agent.plist"
        echo "  - Stop:    sudo launchctl unload /Library/LaunchDaemons/com.apimonitor.agent.plist"
        echo "  - Logs:    tail -f /var/log/api-monitor-agent.log"
    else
        echo "  - Start:   sudo systemctl start api-monitor-agent"
        echo "  - Stop:    sudo systemctl stop api-monitor-agent"
        echo "  - Status:  sudo systemctl status api-monitor-agent"
        echo "  - Logs:    sudo journalctl -u api-monitor-agent -f"
    fi
    echo
    echo "Health Check:"
    echo "  - URL: http://localhost:$AGENT_PORT/health"
    echo
    print_status "The agent should automatically connect to the central dashboard."
    print_status "Check the dashboard to see if this agent appears in the agent list."
}

# Function to prompt for user input
prompt_config() {
    echo
    print_status "API Monitor Agent Installation"
    echo "======================================"
    echo
    
    # Central Dashboard URL
    while [[ -z "$CENTRAL_DASHBOARD" ]]; do
        read -p "Enter Central Dashboard URL (e.g., http://localhost:3000): " CENTRAL_DASHBOARD
        if [[ ! "$CENTRAL_DASHBOARD" =~ ^https?:// ]]; then
            print_warning "Please enter a valid URL starting with http:// or https://"
            CENTRAL_DASHBOARD=""
        fi
    done
    
    # Agent Name
    if [[ -z "$AGENT_NAME" ]]; then
        DEFAULT_NAME="Agent-$(hostname)"
        read -p "Enter Agent Name [$DEFAULT_NAME]: " AGENT_NAME
        AGENT_NAME=${AGENT_NAME:-$DEFAULT_NAME}
    fi
    
    # Port
    read -p "Enter Agent Port [$AGENT_PORT]: " input_port
    if [[ -n "$input_port" ]]; then
        AGENT_PORT=$input_port
    fi
    
    echo
    print_status "Configuration Summary:"
    echo "  - Agent Name: $AGENT_NAME"
    echo "  - Port: $AGENT_PORT"
    echo "  - Central Dashboard: $CENTRAL_DASHBOARD"
    echo
    read -p "Continue with installation? (y/N): " confirm
    if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
        print_status "Installation cancelled"
        exit 0
    fi
}

# Main installation function
main() {
    print_status "Starting API Monitor Agent installation..."
    
    check_root
    detect_os
    prompt_config
    
    install_nodejs
    create_user
    install_agent
    create_config
    create_service
    start_service
    show_status
}

# Command line argument parsing
while [[ $# -gt 0 ]]; do
    case $1 in
        --central-dashboard)
            CENTRAL_DASHBOARD="$2"
            shift 2
            ;;
        --agent-name)
            AGENT_NAME="$2"
            shift 2
            ;;
        --port)
            AGENT_PORT="$2"
            shift 2
            ;;
        --agent-dir)
            AGENT_DIR="$2"
            shift 2
            ;;
        --help)
            echo "API Monitor Agent Installer"
            echo ""
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --central-dashboard URL   Central dashboard URL"
            echo "  --agent-name NAME         Agent name"
            echo "  --port PORT              Agent port (default: 8080)"
            echo "  --agent-dir DIR          Installation directory (default: /opt/api-monitor-agent)"
            echo "  --help                   Show this help message"
            echo ""
            exit 0
            ;;
        *)
            print_error "Unknown option: $1"
            echo "Use --help for usage information"
            exit 1
            ;;
    esac
done

# Run main installation
main 