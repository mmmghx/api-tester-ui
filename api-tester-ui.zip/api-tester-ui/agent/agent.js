#!/usr/bin/env node

const express = require('express');
const WebSocket = require('ws');
const fetch = require('node-fetch');
const schedule = require('node-schedule');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const path = require('path');
const os = require('os');
const minimist = require('minimist');

class APIMonitorAgent {
    constructor(options = {}) {
        this.agentId = options.agentId || this.generateAgentId();
        this.agentName = options.agentName || `Agent-${os.hostname()}`;
        this.port = options.port || 8080;
        this.centralDashboard = options.centralDashboard || 'ws://localhost:3000';
        
        this.app = express();
        this.ws = null;
        this.jobs = new Map(); // 스케줄된 작업들
        this.monitors = new Map(); // 할당된 모니터링들
        this.isConnected = false;
        
        this.setupExpress();
        this.setupWebSocket();
        
        console.log(`🤖 API Monitor Agent v1.0.0`);
        console.log(`📡 Agent ID: ${this.agentId}`);
        console.log(`🏷️  Agent Name: ${this.agentName}`);
        console.log(`🌐 Port: ${this.port}`);
        console.log(`🎯 Central Dashboard: ${this.centralDashboard}`);
    }
    
    generateAgentId() {
        return `agent-${uuidv4().split('-')[0]}-${Date.now()}`;
    }
    
    setupExpress() {
        this.app.use(express.json());
        
        // 헬스체크 엔드포인트
        this.app.get('/health', (req, res) => {
            res.json({
                status: 'healthy',
                agentId: this.agentId,
                agentName: this.agentName,
                uptime: process.uptime(),
                connected: this.isConnected,
                activeMonitors: this.monitors.size,
                activeJobs: this.jobs.size,
                systemInfo: {
                    hostname: os.hostname(),
                    platform: os.platform(),
                    arch: os.arch(),
                    cpus: os.cpus().length,
                    memory: {
                        total: Math.round(os.totalmem() / 1024 / 1024),
                        free: Math.round(os.freemem() / 1024 / 1024)
                    }
                },
                timestamp: new Date().toISOString()
            });
        });
        
        // 모니터링 목록 조회
        this.app.get('/monitors', (req, res) => {
            const monitorList = Array.from(this.monitors.values());
            res.json({
                count: monitorList.length,
                monitors: monitorList
            });
        });
        
        // 특정 모니터링 수동 실행
        this.app.post('/monitors/:id/execute', async (req, res) => {
            const monitorId = req.params.id;
            const monitor = this.monitors.get(monitorId);
            
            if (!monitor) {
                return res.status(404).json({ error: 'Monitor not found' });
            }
            
            try {
                const result = await this.executeMonitor(monitor);
                res.json({
                    success: true,
                    result: result
                });
            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });
    }
    
    setupWebSocket() {
        this.connectToCenter();
        
        // 재연결 로직
        setInterval(() => {
            if (!this.isConnected) {
                console.log('🔄 Attempting to reconnect to central dashboard...');
                this.connectToCenter();
            }
        }, 30000); // 30초마다 재연결 시도
    }
    
    connectToCenter() {
        try {
            const wsUrl = this.centralDashboard.replace('http', 'ws') + '/agent-ws';
            this.ws = new WebSocket(wsUrl);
            
            this.ws.on('open', () => {
                console.log('✅ Connected to central dashboard');
                this.isConnected = true;
                
                // 에이전트 등록
                this.sendToCenter({
                    type: 'agent_register',
                    data: {
                        agentId: this.agentId,
                        agentName: this.agentName,
                        endpoint: `http://${this.getLocalIP()}:${this.port}`,
                        capabilities: {
                            maxConcurrentMonitors: 50,
                            supportedProtocols: ['HTTP', 'HTTPS'],
                            supportedMethods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD', 'OPTIONS']
                        },
                        systemInfo: {
                            hostname: os.hostname(),
                            platform: os.platform(),
                            arch: os.arch(),
                            nodeVersion: process.version
                        }
                    }
                });
            });
            
            this.ws.on('message', (data) => {
                try {
                    const message = JSON.parse(data);
                    this.handleCenterMessage(message);
                } catch (error) {
                    console.error('❌ Error parsing message from center:', error);
                }
            });
            
            this.ws.on('close', () => {
                console.log('🔌 Disconnected from central dashboard');
                this.isConnected = false;
            });
            
            this.ws.on('error', (error) => {
                console.error('❌ WebSocket error:', error.message);
                this.isConnected = false;
            });
            
        } catch (error) {
            console.error('❌ Error connecting to central dashboard:', error.message);
        }
    }
    
    handleCenterMessage(message) {
        console.log(`📨 Received from center: ${message.type}`);
        
        switch (message.type) {
            case 'monitor_assign':
                this.assignMonitor(message.data);
                break;
                
            case 'monitor_remove':
                this.removeMonitor(message.data.monitorId);
                break;
                
            case 'monitor_update':
                this.updateMonitor(message.data);
                break;
                
            case 'ping':
                this.sendToCenter({
                    type: 'pong',
                    data: { agentId: this.agentId, timestamp: Date.now() }
                });
                break;
                
            case 'status_request':
                this.sendStatus();
                break;
                
            default:
                console.log(`⚠️ Unknown message type: ${message.type}`);
        }
    }
    
    assignMonitor(monitor) {
        console.log(`📋 Assigning monitor: ${monitor.name} (${monitor.id})`);
        
        // 기존 작업이 있다면 정지
        if (this.jobs.has(monitor.id)) {
            this.jobs.get(monitor.id).cancel();
        }
        
        this.monitors.set(monitor.id, monitor);
        
        // 스케줄 설정
        const cronExpression = this.intervalToCron(monitor.interval);
        const job = schedule.scheduleJob(cronExpression, () => {
            this.executeMonitor(monitor);
        });
        
        this.jobs.set(monitor.id, job);
        
        console.log(`⏰ Scheduled monitor "${monitor.name}" every ${monitor.interval} minutes`);
    }
    
    removeMonitor(monitorId) {
        console.log(`🗑️ Removing monitor: ${monitorId}`);
        
        if (this.jobs.has(monitorId)) {
            this.jobs.get(monitorId).cancel();
            this.jobs.delete(monitorId);
        }
        
        this.monitors.delete(monitorId);
    }
    
    updateMonitor(monitor) {
        console.log(`📝 Updating monitor: ${monitor.name} (${monitor.id})`);
        this.removeMonitor(monitor.id);
        this.assignMonitor(monitor);
    }
    
    async executeMonitor(monitor) {
        const startTime = Date.now();
        
        console.log(`🔍 Executing monitor: ${monitor.name}`);
        
        try {
            const response = await fetch(monitor.url, {
                method: monitor.method || 'GET',
                headers: monitor.headers || {},
                body: monitor.body || undefined,
                timeout: 30000 // 30초 타임아웃
            });
            
            const endTime = Date.now();
            const responseTime = endTime - startTime;
            
            const result = {
                monitorId: monitor.id,
                monitorName: monitor.name,
                agentId: this.agentId,
                agentName: this.agentName,
                status: response.status >= 200 && response.status < 300 ? 'success' : 'error',
                statusCode: response.status,
                responseTime: responseTime,
                timestamp: new Date().toISOString(),
                url: monitor.url,
                method: monitor.method || 'GET',
                headers: Object.fromEntries(response.headers.entries()),
                error: null
            };
            
            // 중앙 대시보드로 결과 전송
            this.sendToCenter({
                type: 'monitor_result',
                data: result
            });
            
            console.log(`✅ Monitor "${monitor.name}" completed: ${response.status} (${responseTime}ms)`);
            
            return result;
            
        } catch (error) {
            const endTime = Date.now();
            const responseTime = endTime - startTime;
            
            const result = {
                monitorId: monitor.id,
                monitorName: monitor.name,
                agentId: this.agentId,
                agentName: this.agentName,
                status: 'error',
                statusCode: null,
                responseTime: responseTime,
                timestamp: new Date().toISOString(),
                url: monitor.url,
                method: monitor.method || 'GET',
                headers: {},
                error: error.message
            };
            
            // 중앙 대시보드로 결과 전송
            this.sendToCenter({
                type: 'monitor_result',
                data: result
            });
            
            console.error(`❌ Monitor "${monitor.name}" failed: ${error.message}`);
            
            return result;
        }
    }
    
    sendToCenter(message) {
        if (this.ws && this.isConnected) {
            this.ws.send(JSON.stringify(message));
        }
    }
    
    sendStatus() {
        const status = {
            agentId: this.agentId,
            agentName: this.agentName,
            status: 'healthy',
            uptime: process.uptime(),
            activeMonitors: this.monitors.size,
            activeJobs: this.jobs.size,
            lastSeen: new Date().toISOString()
        };
        
        this.sendToCenter({
            type: 'agent_status',
            data: status
        });
    }
    
    intervalToCron(minutes) {
        // 분 단위를 cron 표현식으로 변환
        if (minutes < 1) {
            return '*/30 * * * * *'; // 30초마다
        } else if (minutes >= 60) {
            const hours = Math.floor(minutes / 60);
            return `0 0 */${hours} * * *`; // N시간마다
        } else {
            return `0 */${Math.round(minutes)} * * * *`; // N분마다
        }
    }
    
    getLocalIP() {
        const interfaces = os.networkInterfaces();
        for (const name of Object.keys(interfaces)) {
            for (const networkInterface of interfaces[name]) {
                if (networkInterface.family === 'IPv4' && !networkInterface.internal) {
                    return networkInterface.address;
                }
            }
        }
        return 'localhost';
    }
    
    start() {
        this.app.listen(this.port, () => {
            console.log(`🚀 Agent server running on port ${this.port}`);
            console.log(`📊 Health check: http://localhost:${this.port}/health`);
            
            // 정기적으로 상태 전송
            setInterval(() => {
                if (this.isConnected) {
                    this.sendStatus();
                }
            }, 60000); // 1분마다
        });
    }
    
    stop() {
        console.log('🛑 Stopping agent...');
        
        // 모든 스케줄된 작업 정지
        for (const job of this.jobs.values()) {
            job.cancel();
        }
        
        // WebSocket 연결 종료
        if (this.ws) {
            this.ws.close();
        }
        
        console.log('✅ Agent stopped');
        process.exit(0);
    }
}

// CLI 실행
if (require.main === module) {
    const args = minimist(process.argv.slice(2));
    
    const options = {
        agentId: args.id || args.agentId,
        agentName: args.name || args.agentName,
        port: parseInt(args.port || args.p) || 8080,
        centralDashboard: args.central || args.dashboard || 'ws://localhost:3000'
    };
    
    const agent = new APIMonitorAgent(options);
    
    // 시그널 핸들링
    process.on('SIGINT', () => agent.stop());
    process.on('SIGTERM', () => agent.stop());
    
    agent.start();
}

module.exports = APIMonitorAgent; 