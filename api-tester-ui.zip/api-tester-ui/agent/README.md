# API Monitor Agent

분산 API 모니터링을 위한 에이전트 시스템입니다. 여러 서버에 설치하여 중앙 대시보드에서 관리할 수 있습니다.

## 🚀 빠른 설치

### 자동 설치 (권장)

```bash
# 저장소 다운로드
curl -L https://github.com/your-org/api-monitor/archive/main.zip -o api-monitor.zip
unzip api-monitor.zip
cd api-monitor-main/agent

# 설치 실행
sudo ./install.sh
```

### 수동 설치

```bash
# 1. Node.js 설치 (18.x 이상)
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# 2. 에이전트 파일 다운로드
mkdir -p /opt/api-monitor-agent
cd /opt/api-monitor-agent

# 방법 1: 압축 파일 다운로드
curl -L "http://YOUR_CENTRAL_SERVER:3000/api/agent-package" -o api-monitor-agent.tar.gz
tar -xzf api-monitor-agent.tar.gz
rm api-monitor-agent.tar.gz

# 방법 2: 설치 스크립트 사용 (권장)
curl -fsSL "http://YOUR_CENTRAL_SERVER:3000/agent-installer.sh" | bash -s YOUR_CENTRAL_SERVER_IP

# 방법 3: 개별 파일 다운로드
curl -L "http://YOUR_CENTRAL_SERVER:3000/api/agent-code" -o agent.js
# package.json은 수동으로 생성하거나 별도 제공

# 3. 의존성 설치
npm install --production

# 4. 서비스 사용자 생성
sudo useradd --system --shell /bin/false api-monitor

# 5. 권한 설정
sudo chown -R api-monitor:api-monitor /opt/api-monitor-agent
```

## ⚙️ 설정

### 기본 설정

```json
{
  "agentName": "Agent-hostname",
  "port": 8080,
  "centralDashboard": "ws://localhost:3000",
  "logLevel": "info",
  "maxConcurrentMonitors": 50,
  "healthCheckInterval": 60000,
  "reconnectInterval": 30000
}
```

### 환경 변수

| 변수명 | 설명 | 기본값 |
|--------|------|--------|
| `AGENT_NAME` | 에이전트 이름 | `Agent-hostname` |
| `AGENT_PORT` | 에이전트 포트 | `8080` |
| `CENTRAL_DASHBOARD` | 중앙 대시보드 URL | `ws://localhost:3000` |
| `LOG_LEVEL` | 로그 레벨 | `info` |

## 🔧 사용법

### 명령줄 옵션

```bash
# 기본 실행
node agent.js

# 커스텀 설정으로 실행
node agent.js --name "Production-Agent" --port 8081 --central "ws://dashboard.company.com:3000"

# 설정 파일 사용
node agent.js --config /path/to/config.json
```

### 서비스 관리

#### Linux (systemd)

```bash
# 서비스 시작
sudo systemctl start api-monitor-agent

# 서비스 중지
sudo systemctl stop api-monitor-agent

# 서비스 상태 확인
sudo systemctl status api-monitor-agent

# 로그 확인
sudo journalctl -u api-monitor-agent -f

# 부팅 시 자동 시작 설정
sudo systemctl enable api-monitor-agent
```

#### macOS (launchd)

```bash
# 서비스 시작
sudo launchctl load /Library/LaunchDaemons/com.apimonitor.agent.plist

# 서비스 중지
sudo launchctl unload /Library/LaunchDaemons/com.apimonitor.agent.plist

# 로그 확인
tail -f /var/log/api-monitor-agent.log
```

## 📊 모니터링

### 헬스체크

```bash
curl http://localhost:8080/health
```

**응답 예시:**
```json
{
  "status": "healthy",
  "agentId": "agent-abc123-1640995200000",
  "agentName": "Agent-server01",
  "uptime": 3600.5,
  "connected": true,
  "activeMonitors": 5,
  "activeJobs": 5,
  "systemInfo": {
    "hostname": "server01",
    "platform": "linux",
    "arch": "x64",
    "cpus": 4,
    "memory": {
      "total": 8192,
      "free": 4096
    }
  },
  "timestamp": "2024-01-01T12:00:00.000Z"
}
```

### 활성 모니터링 조회

```bash
curl http://localhost:8080/monitors
```

### 수동 모니터링 실행

```bash
curl -X POST http://localhost:8080/monitors/{monitor-id}/execute
```

## 🌐 네트워크 요구사항

### 아웃바운드 연결

- **중앙 대시보드**: WebSocket 연결 (포트 3000)
- **모니터링 대상 API**: HTTP/HTTPS 연결 (다양한 포트)

### 인바운드 연결

- **헬스체크 포트**: 8080 (설정 가능)

### 방화벽 설정

```bash
# 아웃바운드 (중앙 대시보드로의 연결)
sudo ufw allow out 3000

# 인바운드 (헬스체크 포트)
sudo ufw allow 8080
```

## 🐳 Docker 실행

### Docker 이미지 빌드

```bash
# Dockerfile 생성
cat > Dockerfile << EOF
FROM node:18-alpine

WORKDIR /app
COPY package*.json ./
RUN npm install --production

COPY . .

USER node
EXPOSE 8080

CMD ["node", "agent.js"]
EOF

# 이미지 빌드
docker build -t api-monitor-agent .
```

### Docker 실행

```bash
docker run -d \
  --name api-monitor-agent \
  --restart unless-stopped \
  -p 8080:8080 \
  -e AGENT_NAME="Docker-Agent" \
  -e CENTRAL_DASHBOARD="ws://host.docker.internal:3000" \
  api-monitor-agent
```

### Docker Compose

```yaml
version: '3.8'

services:
  api-monitor-agent:
    build: .
    container_name: api-monitor-agent
    restart: unless-stopped
    ports:
      - "8080:8080"
    environment:
      - AGENT_NAME=Docker-Agent
      - CENTRAL_DASHBOARD=ws://dashboard:3000
    networks:
      - monitoring

networks:
  monitoring:
    external: true
```

## 🔒 보안 고려사항

### SSL/TLS 설정

중앙 대시보드가 HTTPS를 사용하는 경우:

```json
{
  "centralDashboard": "wss://dashboard.company.com:3000",
  "ssl": {
    "enabled": true,
    "rejectUnauthorized": true,
    "ca": "/path/to/ca.pem",
    "cert": "/path/to/client.pem",
    "key": "/path/to/client-key.pem"
  }
}
```

### 인증 토큰

```json
{
  "auth": {
    "type": "token",
    "token": "your-agent-token-here"
  }
}
```

## 🚨 문제 해결

### 일반적인 문제

#### 1. 중앙 대시보드 연결 실패

```bash
# 네트워크 연결 확인
telnet dashboard-host 3000

# DNS 해석 확인
nslookup dashboard-host

# 방화벽 확인
sudo ufw status
```

#### 2. 메모리 부족

```bash
# 메모리 사용량 확인
ps aux | grep node

# 시스템 메모리 확인
free -h

# 스왑 추가 (필요한 경우)
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
```

#### 3. 로그 확인

```bash
# systemd 로그
sudo journalctl -u api-monitor-agent --since "1 hour ago"

# 에이전트 로그 파일
tail -f /var/log/api-monitor-agent.log

# 디버그 모드 실행
LOG_LEVEL=debug node agent.js
```

### 성능 튜닝

#### 메모리 사용량 최적화

```bash
# Node.js 힙 크기 제한
node --max-old-space-size=512 agent.js
```

#### 동시 연결 수 제한

```json
{
  "maxConcurrentMonitors": 20,
  "requestTimeout": 30000,
  "keepAlive": true
}
```

## 📦 제거

### 자동 제거

```bash
# 서비스 중지 및 제거
sudo systemctl stop api-monitor-agent
sudo systemctl disable api-monitor-agent
sudo rm /etc/systemd/system/api-monitor-agent.service

# 파일 제거
sudo rm -rf /opt/api-monitor-agent

# 사용자 제거
sudo userdel api-monitor
```

### macOS 제거

```bash
# 서비스 중지
sudo launchctl unload /Library/LaunchDaemons/com.apimonitor.agent.plist

# 설정 파일 제거
sudo rm /Library/LaunchDaemons/com.apimonitor.agent.plist

# 에이전트 파일 제거
sudo rm -rf /opt/api-monitor-agent
```

## 📞 지원

- **이슈 리포팅**: GitHub Issues
- **문서**: [Wiki 페이지](https://github.com/your-org/api-monitor/wiki)
- **이메일**: support@yourcompany.com

## 📄 라이센스

MIT License - [LICENSE](LICENSE) 파일 참조 