const express = require('express');
const cors = require('cors');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const cron = require('node-cron');
const http = require('http');
const WebSocket = require('ws');

const app = express();
const server = http.createServer(app);
const PORT = process.env.PORT || 3000;

// Agent 관리 시스템
class AgentManager {
    constructor() {
        this.agents = new Map(); // agentId -> agent정보
        this.agentConnections = new Map(); // agentId -> WebSocket connection
        this.monitorAssignments = new Map(); // monitorId -> agentId
    }
    
    registerAgent(agentData, ws) {
        console.log(`🤖 Agent registered: ${agentData.agentName} (${agentData.agentId})`);
        
        this.agents.set(agentData.agentId, {
            ...agentData,
            status: 'online',
            lastSeen: new Date().toISOString(),
            registeredAt: new Date().toISOString()
        });
        
        this.agentConnections.set(agentData.agentId, ws);
        
        // 연결 종료 시 정리
        ws.on('close', () => {
            this.setAgentOffline(agentData.agentId);
        });
        
        return true;
    }
    
    setAgentOffline(agentId) {
        if (this.agents.has(agentId)) {
            const agent = this.agents.get(agentId);
            agent.status = 'offline';
            agent.lastSeen = new Date().toISOString();
            console.log(`🔌 Agent disconnected: ${agent.agentName} (${agentId})`);
        }
        this.agentConnections.delete(agentId);
    }
    
    getAgentList() {
        return Array.from(this.agents.values());
    }
    
    getOnlineAgents() {
        return Array.from(this.agents.values()).filter(agent => agent.status === 'online');
    }
    
    assignMonitorToAgent(agentId, monitor) {
        const ws = this.agentConnections.get(agentId);
        if (ws && ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({
                type: 'monitor_assign',
                data: monitor
            }));
            this.monitorAssignments.set(monitor.id, agentId);
            console.log(`📋 Monitor "${monitor.name}" assigned to agent ${agentId}`);
            return true;
        }
        return false;
    }
    
    removeMonitorFromAgent(agentId, monitorId) {
        const ws = this.agentConnections.get(agentId);
        if (ws && ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({
                type: 'monitor_remove',
                data: { monitorId }
            }));
            this.monitorAssignments.delete(monitorId);
            console.log(`🗑️ Monitor ${monitorId} removed from agent ${agentId}`);
            return true;
        }
        return false;
    }
    
    getAssignedAgent(monitorId) {
        return this.monitorAssignments.get(monitorId);
    }
    
    broadcastToAllAgents(message) {
        let sentCount = 0;
        for (const [agentId, ws] of this.agentConnections) {
            if (ws.readyState === WebSocket.OPEN) {
                ws.send(JSON.stringify(message));
                sentCount++;
            }
        }
        return sentCount;
    }
    
    updateAgentStatus(agentId, status) {
        if (this.agents.has(agentId)) {
            const agent = this.agents.get(agentId);
            Object.assign(agent, status);
            agent.lastSeen = new Date().toISOString();
        }
    }
}

const agentManager = new AgentManager();

// SQLite 데이터베이스 설정
const db = new sqlite3.Database('./api_monitor.db');

// 데이터베이스 테이블 초기화
db.serialize(() => {
    // 모니터링 테이블
    db.run(`
        CREATE TABLE IF NOT EXISTS monitors (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            url TEXT NOT NULL,
            method TEXT NOT NULL,
            interval_minutes INTEGER NOT NULL,
            headers TEXT,
            body TEXT,
            active BOOLEAN DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_check DATETIME,
            status TEXT DEFAULT 'waiting'
        )
    `);
    
    // 결과 테이블
    db.run(`
        CREATE TABLE IF NOT EXISTS results (
            id TEXT PRIMARY KEY,
            monitor_id TEXT NOT NULL,
            monitor_name TEXT NOT NULL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            status TEXT NOT NULL,
            status_code INTEGER,
            response_time INTEGER,
            message TEXT,
            response_size INTEGER,
            execution_location TEXT DEFAULT '브라우저',
            FOREIGN KEY (monitor_id) REFERENCES monitors (id)
        )
    `);
    
    // execution_location 컬럼 추가 (기존 테이블에 없는 경우)
    db.run(`
        ALTER TABLE results 
        ADD COLUMN execution_location TEXT DEFAULT '브라우저'
    `, function(err) {
        if (err && !err.message.includes('duplicate column name')) {
            console.error('컬럼 추가 실패:', err.message);
        }
    });
    
    // 인덱스 생성
    db.run(`CREATE INDEX IF NOT EXISTS idx_results_timestamp ON results (timestamp)`);
    db.run(`CREATE INDEX IF NOT EXISTS idx_results_monitor_id ON results (monitor_id)`);
});

// 2년 이상 된 데이터 자동 삭제 (매일 자정 실행)
cron.schedule('0 0 * * *', () => {
    const twoYearsAgo = new Date();
    twoYearsAgo.setFullYear(twoYearsAgo.getFullYear() - 2);
    
    db.run(
        'DELETE FROM results WHERE timestamp < ?',
        [twoYearsAgo.toISOString()],
        function(err) {
            if (err) {
                console.error('자동 삭제 실패:', err);
            } else {
                console.log(`자동 삭제 완료: ${this.changes}개 레코드 삭제`);
            }
        }
    );
});

// WebSocket 서버 설정 (에이전트 통신용)
const wss = new WebSocket.Server({ 
    server,
    path: '/agent-ws'
});

wss.on('connection', (ws, req) => {
    console.log('🔗 New WebSocket connection from:', req.socket.remoteAddress);
    
    // 에이전트 등록 대기
    let agentId = null;
    let isRegistered = false;
    
    ws.on('message', (data) => {
        try {
            const message = JSON.parse(data);
            
            switch (message.type) {
                case 'agent_register':
                    if (agentManager.registerAgent(message.data, ws)) {
                        agentId = message.data.agentId;
                        isRegistered = true;
                        
                        // 등록 성공 응답
                        ws.send(JSON.stringify({
                            type: 'register_success',
                            data: { agentId: agentId }
                        }));
                    }
                    break;
                    
                case 'agent_status':
                    if (isRegistered) {
                        agentManager.updateAgentStatus(agentId, message.data);
                    }
                    break;
                    
                case 'monitor_result':
                    if (isRegistered) {
                        // 모니터링 결과를 데이터베이스에 저장
                        const result = message.data;
                        const resultId = `result-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
                        const agent = agentManager.agents.get(agentId);
                        const executionLocation = agent ? agent.agentName : 'Unknown Agent';
                        
                        db.run(
                            `INSERT INTO results (id, monitor_id, monitor_name, status, status_code, response_time, message, response_size, execution_location)
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                            [
                                resultId,
                                result.monitorId,
                                result.monitorName,
                                result.status,
                                result.statusCode,
                                result.responseTime,
                                result.error || 'OK',
                                0, // response_size는 현재 미사용
                                executionLocation
                            ],
                            function(err) {
                                if (err) {
                                    console.error('결과 저장 실패:', err.message);
                                } else {
                                    console.log(`📊 Result saved from ${executionLocation}: ${result.monitorName} - ${result.status}`);
                                }
                            }
                        );
                        
                        // 모니터 상태 업데이트
                        db.run(
                            'UPDATE monitors SET last_check = ?, status = ? WHERE id = ?',
                            [result.timestamp, result.status, result.monitorId],
                            function(err) {
                                if (err) {
                                    console.error('모니터 상태 업데이트 실패:', err.message);
                                }
                            }
                        );
                    }
                    break;
                    
                case 'pong':
                    // Heartbeat 응답 - 특별한 처리 불필요
                    break;
                    
                default:
                    console.log(`⚠️ Unknown message type from agent: ${message.type}`);
            }
            
        } catch (error) {
            console.error('❌ Error parsing WebSocket message:', error);
        }
    });
    
    ws.on('close', () => {
        if (isRegistered && agentId) {
            agentManager.setAgentOffline(agentId);
        }
    });
    
    ws.on('error', (error) => {
        console.error('❌ WebSocket error:', error);
    });
});

// 에이전트 상태 확인 (5분마다)
setInterval(() => {
    const onlineAgents = agentManager.getOnlineAgents();
    console.log(`💓 Heartbeat: ${onlineAgents.length} agents online`);
    
    // 모든 온라인 에이전트에게 ping 전송
    agentManager.broadcastToAllAgents({
        type: 'ping',
        timestamp: Date.now()
    });
}, 5 * 60 * 1000);

// CORS 설정
app.use(cors({
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Accept', 'Origin'],
    credentials: true
}));

// Body parser 미들웨어
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(express.text({ limit: '10mb' }));

// 정적 파일 서빙
app.use(express.static(path.join(__dirname)));

// 기본 라우트
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// API 프록시 (CORS 이슈 해결용)
app.all('/api-proxy/*', async (req, res) => {
    let targetUrl = req.url.replace('/api-proxy/', '');
    
    // URL 디코딩 (이중 인코딩 문제 해결)
    try {
        targetUrl = decodeURIComponent(targetUrl);
    } catch (e) {
        // 이미 디코딩된 URL일 수 있음
        console.log('URL 디코딩 실패, 원본 사용:', targetUrl);
    }
    
    console.log(`🎯 Decoded Target URL: ${targetUrl}`);
    
    if (!targetUrl.startsWith('http')) {
        console.error(`❌ Invalid URL: ${targetUrl}`);
        return res.status(400).json({ 
            error: 'Invalid URL. Must start with http:// or https://',
            receivedUrl: targetUrl,
            originalUrl: req.url
        });
    }

    console.log(`🔄 Proxying ${req.method} ${targetUrl}`);
    console.log('📋 Headers:', req.headers);
    console.log('📝 Body:', req.body);

    try {
        const fetch = await import('node-fetch').then(module => module.default);
        
        // 요청 헤더 준비
        const headers = {};
        Object.keys(req.headers).forEach(key => {
            // 브라우저/프록시 관련 헤더 제외
            if (!['host', 'connection', 'accept-encoding', 'user-agent', 'referer', 'origin'].includes(key.toLowerCase())) {
                headers[key] = req.headers[key];
            }
        });

        // fetch 옵션 구성
        const fetchOptions = {
            method: req.method,
            headers: headers
        };

        // Body 추가 (GET, HEAD 제외)
        if (!['GET', 'HEAD'].includes(req.method) && req.body) {
            if (typeof req.body === 'string') {
                fetchOptions.body = req.body;
            } else if (req.body instanceof Buffer) {
                fetchOptions.body = req.body;
            } else {
                fetchOptions.body = JSON.stringify(req.body);
                if (!headers['content-type']) {
                    headers['content-type'] = 'application/json';
                }
            }
        }

        // API 호출
        const startTime = Date.now();
        const response = await fetch(targetUrl, fetchOptions);
        const endTime = Date.now();

        console.log(`✅ Response: ${response.status} ${response.statusText} (${endTime - startTime}ms)`);

        // 응답 헤더 설정 (압축 관련 헤더 제외)
        response.headers.forEach((value, key) => {
            // content-encoding과 content-length 헤더는 제외
            // (node-fetch가 이미 압축을 해제했으므로)
            if (!['content-encoding', 'content-length'].includes(key.toLowerCase())) {
                res.set(key, value);
            }
        });

        // CORS 헤더 추가
        res.set('Access-Control-Allow-Origin', '*');
        res.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, HEAD, OPTIONS');
        res.set('Access-Control-Allow-Headers', '*');

        // 응답 상태 설정
        res.status(response.status);

        // 응답 본문 처리
        const contentType = response.headers.get('content-type') || '';
        
        if (contentType.includes('application/json')) {
            const jsonData = await response.json();
            res.json(jsonData);
        } else if (contentType.includes('text/')) {
            const textData = await response.text();
            res.send(textData);
        } else {
            const buffer = await response.buffer();
            res.send(buffer);
        }

    } catch (error) {
        console.error('❌ Proxy error:', error.message);
        res.status(500).json({
            error: 'Proxy request failed',
            message: error.message,
            targetUrl: targetUrl
        });
    }
});

// 에이전트 관리 API 엔드포인트

// 모든 에이전트 조회
app.get('/api/agents', (req, res) => {
    const agents = agentManager.getAgentList();
    res.json({
        total: agents.length,
        online: agents.filter(a => a.status === 'online').length,
        offline: agents.filter(a => a.status === 'offline').length,
        agents: agents
    });
});

// 특정 에이전트 상세 정보
app.get('/api/agents/:agentId', (req, res) => {
    const agents = agentManager.getAgentList();
    const agent = agents.find(a => a.agentId === req.params.agentId);
    
    if (!agent) {
        return res.status(404).json({ error: 'Agent not found' });
    }
    
    res.json(agent);
});

// 에이전트에 모니터링 할당
app.post('/api/agents/:agentId/assign', (req, res) => {
    const { agentId } = req.params;
    const { monitorId } = req.body;
    
    // 모니터링 정보 조회
    db.get('SELECT * FROM monitors WHERE id = ?', [monitorId], (err, monitor) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        
        if (!monitor) {
            return res.status(404).json({ error: 'Monitor not found' });
        }
        
        // 모니터링 데이터 변환
        const monitorData = {
            id: monitor.id,
            name: monitor.name,
            url: monitor.url,
            method: monitor.method,
            interval: monitor.interval_minutes,
            headers: JSON.parse(monitor.headers || '{}'),
            body: monitor.body
        };
        
        // 에이전트에 할당
        if (agentManager.assignMonitorToAgent(agentId, monitorData)) {
            res.json({ 
                success: true,
                message: `Monitor ${monitor.name} assigned to agent ${agentId}`
            });
        } else {
            res.status(400).json({ 
                success: false,
                error: 'Agent not found or offline' 
            });
        }
    });
});

// 에이전트에서 모니터링 제거
app.delete('/api/agents/:agentId/monitors/:monitorId', (req, res) => {
    const { agentId, monitorId } = req.params;
    
    if (agentManager.removeMonitorFromAgent(agentId, monitorId)) {
        res.json({ 
            success: true,
            message: `Monitor ${monitorId} removed from agent ${agentId}`
        });
    } else {
        res.status(400).json({ 
            success: false,
            error: 'Agent not found or offline' 
        });
    }
});

// 온라인 에이전트 목록 (모니터링 할당용)
app.get('/api/agents/online', (req, res) => {
    const onlineAgents = agentManager.getOnlineAgents();
    res.json(onlineAgents);
});

// 모니터링 API 엔드포인트

// 모든 모니터링 조회
app.get('/api/monitors', (req, res) => {
    db.all('SELECT * FROM monitors ORDER BY created_at DESC', (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json(rows);
        }
    });
});

// 모니터링 추가
app.post('/api/monitors', (req, res) => {
    const { id, name, url, method, interval_minutes, headers, body } = req.body;
    
    db.run(
        `INSERT INTO monitors (id, name, url, method, interval_minutes, headers, body) 
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [id, name, url, method, interval_minutes, JSON.stringify(headers || {}), body],
        function(err) {
            if (err) {
                res.status(500).json({ error: err.message });
            } else {
                res.json({ message: 'Monitor created', id: id });
            }
        }
    );
});

// 모니터링 상태 업데이트
app.put('/api/monitors/:id', (req, res) => {
    const { active, status, last_check } = req.body;
    
    db.run(
        'UPDATE monitors SET active = ?, status = ?, last_check = ? WHERE id = ?',
        [active, status, last_check, req.params.id],
        function(err) {
            if (err) {
                res.status(500).json({ error: err.message });
            } else {
                res.json({ message: 'Monitor updated', changes: this.changes });
            }
        }
    );
});

// 모니터링 삭제
app.delete('/api/monitors/:id', (req, res) => {
    db.run('DELETE FROM monitors WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            // 관련 결과도 삭제
            db.run('DELETE FROM results WHERE monitor_id = ?', [req.params.id], function(err2) {
                if (err2) {
                    console.warn('결과 삭제 실패:', err2.message);
                }
                res.json({ message: 'Monitor deleted', changes: this.changes });
            });
        }
    });
});

// 결과 추가
app.post('/api/results', (req, res) => {
    const { id, monitor_id, monitor_name, status, status_code, response_time, message, response_size } = req.body;
    
    db.run(
        `INSERT INTO results (id, monitor_id, monitor_name, status, status_code, response_time, message, response_size)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [id, monitor_id, monitor_name, status, status_code, response_time, message, response_size],
        function(err) {
            if (err) {
                res.status(500).json({ error: err.message });
            } else {
                res.json({ message: 'Result saved', id: id });
            }
        }
    );
});

// 결과 조회
app.get('/api/results', (req, res) => {
    const limit = parseInt(req.query.limit) || 100;
    const offset = parseInt(req.query.offset) || 0;
    
    db.all(
        'SELECT * FROM results ORDER BY timestamp DESC LIMIT ? OFFSET ?',
        [limit, offset],
        (err, rows) => {
            if (err) {
                res.status(500).json({ error: err.message });
            } else {
                res.json(rows);
            }
        }
    );
});

// 통계 조회
app.get('/api/stats', (req, res) => {
    const queries = {
        totalResults: 'SELECT COUNT(*) as count FROM results',
        successCount: 'SELECT COUNT(*) as count FROM results WHERE status = "success"',
        errorCount: 'SELECT COUNT(*) as count FROM results WHERE status = "error"',
        avgResponseTime: 'SELECT AVG(response_time) as avg FROM results WHERE response_time > 0',
        activeMonitors: 'SELECT COUNT(*) as count FROM monitors WHERE active = 1'
    };

    const stats = {};
    let completed = 0;
    const total = Object.keys(queries).length;

    Object.entries(queries).forEach(([key, query]) => {
        db.get(query, (err, row) => {
            if (!err) {
                stats[key] = row.count !== undefined ? row.count : Math.round(row.avg || 0);
            }
            completed++;
            if (completed === total) {
                res.json(stats);
            }
        });
    });
});

// 에이전트 코드 다운로드 API
app.get('/api/agent-code', (req, res) => {
    const agentCodePath = path.join(__dirname, 'agent', 'agent.js');
    
    fs.readFile(agentCodePath, 'utf8', (err, data) => {
        if (err) {
            console.error('에이전트 코드 읽기 실패:', err);
            res.status(500).json({ error: 'Agent code not found' });
            return;
        }
        
        res.setHeader('Content-Type', 'application/javascript');
        res.setHeader('Content-Disposition', 'attachment; filename="agent.js"');
        res.send(data);
    });
});

// 에이전트 패키지 다운로드 API
app.get('/api/agent-package', (req, res) => {
    const packagePath = path.join(__dirname, 'api-monitor-agent.tar.gz');
    
    if (fs.existsSync(packagePath)) {
        res.setHeader('Content-Type', 'application/gzip');
        res.setHeader('Content-Disposition', 'attachment; filename="api-monitor-agent.tar.gz"');
        res.sendFile(packagePath);
    } else {
        res.status(404).json({ error: 'Agent package not found' });
    }
});

// 에이전트 설치 스크립트 다운로드 API
app.get('/agent-installer.sh', (req, res) => {
    const installerPath = path.join(__dirname, 'agent-installer.sh');
    
    if (fs.existsSync(installerPath)) {
        res.setHeader('Content-Type', 'application/x-sh');
        res.setHeader('Content-Disposition', 'attachment; filename="agent-installer.sh"');
        res.sendFile(installerPath);
    } else {
        res.status(404).json({ error: 'Agent installer not found' });
    }
});

// 헬스 체크
app.get('/health', (req, res) => {
    res.json({ 
        status: 'OK', 
        timestamp: new Date().toISOString(),
        uptime: process.uptime()
    });
});

// 404 핸들러
app.use((req, res) => {
    if (req.path.startsWith('/api')) {
        res.status(404).json({ error: 'API endpoint not found' });
    } else {
        res.sendFile(path.join(__dirname, 'index.html'));
    }
});

// 서버 시작
server.listen(PORT, () => {
    console.log('🚀 API Tester UI Server Started!');
    console.log('==========================================');
    console.log(`📡 Server running on: http://localhost:${PORT}`);
    console.log('🌐 Open in browser: http://localhost:3000');
    console.log('🔄 API Proxy available at: /api-proxy/[URL]');
    console.log('💡 Example: /api-proxy/https://jsonplaceholder.typicode.com/posts');
    console.log('🤖 Agent WebSocket: ws://localhost:3000/agent-ws');
    console.log('📊 Agent Management: http://localhost:3000/api/agents');
    console.log('==========================================');
    
    // 자동으로 브라우저 열기 (macOS)
    if (process.platform === 'darwin') {
        const { exec } = require('child_process');
        exec(`open http://localhost:${PORT}`);
    }
}); 