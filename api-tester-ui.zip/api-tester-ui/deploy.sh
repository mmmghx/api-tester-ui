#!/bin/bash

# API Monitor 배포 패키지 생성 스크립트
# Version: 1.0.0

set -e

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_status "API Monitor 배포 패키지 생성 중..."

# 배포 디렉토리 생성
DEPLOY_DIR="api-monitor-dist"
rm -rf $DEPLOY_DIR
mkdir -p $DEPLOY_DIR

print_status "파일 복사 중..."

# 중앙 대시보드 파일들
cp -r *.html *.css *.js package.json $DEPLOY_DIR/
cp README.md $DEPLOY_DIR/ 2>/dev/null || echo "README.md not found, skipping..."

# 에이전트 디렉토리 복사
cp -r agent $DEPLOY_DIR/

# 설치 스크립트 생성
cat > $DEPLOY_DIR/install-dashboard.sh << 'EOF'
#!/bin/bash

# API Monitor 중앙 대시보드 설치 스크립트

set -e

echo "🚀 API Monitor 중앙 대시보드 설치 중..."

# Node.js 확인
if ! command -v node &> /dev/null; then
    echo "❌ Node.js가 설치되어 있지 않습니다."
    echo "https://nodejs.org에서 Node.js를 설치한 후 다시 실행해주세요."
    exit 1
fi

# 의존성 설치
echo "📦 의존성 설치 중..."
npm install

echo "✅ 설치 완료!"
echo ""
echo "사용법:"
echo "  npm start        - 서버 시작"
echo "  open http://localhost:3000 - 브라우저에서 열기"
echo ""
echo "에이전트 설치:"
echo "  cd agent && sudo ./install.sh"
EOF

chmod +x $DEPLOY_DIR/install-dashboard.sh

# 빠른 설치 스크립트
cat > $DEPLOY_DIR/quick-install.sh << 'EOF'
#!/bin/bash

# API Monitor 빠른 설치 스크립트

echo "🚀 API Monitor 빠른 설치"
echo "=========================="

# 중앙 대시보드 설치
echo "📊 중앙 대시보드 설치 중..."
npm install
echo "✅ 중앙 대시보드 설치 완료"

echo ""
echo "🤖 에이전트를 다른 서버에 설치하려면:"
echo "1. agent/ 폴더를 대상 서버에 복사"
echo "2. sudo ./install.sh 실행"
echo ""
echo "서버 시작: npm start"
echo "브라우저: http://localhost:3000"
EOF

chmod +x $DEPLOY_DIR/quick-install.sh

# README 생성
cat > $DEPLOY_DIR/README.md << 'EOF'
# API Monitor - 분산 모니터링 시스템

실시간 API 모니터링과 분산 에이전트 관리를 위한 완전한 솔루션입니다.

## 🚀 빠른 시작

### 중앙 대시보드 설치

```bash
# 자동 설치
./quick-install.sh

# 또는 수동 설치
./install-dashboard.sh
npm start
```

### 에이전트 설치 (다른 서버에)

```bash
cd agent
sudo ./install.sh
```

## 📋 시스템 구성

```
Central Dashboard (Port 3000)
├── Web UI - API 테스트 및 모니터링 관리
├── Agent Management - 에이전트 등록 및 제어
├── WebSocket Server - 에이전트와의 실시간 통신
└── Database - 모니터링 결과 저장

Remote Agents (Port 8080)
├── API Testing Engine - 실제 API 호출 실행
├── Scheduler - 주기적 모니터링 실행
└── WebSocket Client - 중앙 대시보드와 통신
```

## 🌟 주요 기능

### 중앙 대시보드
- **Manual Test**: Postman과 같은 API 테스트 도구
- **Auto Monitor**: 자동화된 주기적 API 모니터링 
- **Dashboard**: 실시간 통계 및 차트
- **Agent Management**: 분산 에이전트 관리
- **URL Routing**: 직접 URL 접근 지원

### 분산 에이전트
- **독립 실행**: 각 서버에서 독립적으로 작동
- **자동 재연결**: 네트워크 장애 시 자동 복구
- **부하 분산**: 여러 에이전트에 모니터링 작업 분산
- **실시간 상태**: 에이전트 상태 실시간 모니터링

## 📊 사용 시나리오

### 시나리오 1: 단일 서버 모니터링
```bash
# 중앙 대시보드만 설치
npm start
# 브라우저에서 로컬 모니터링 설정
```

### 시나리오 2: 다중 서버 분산 모니터링
```bash
# 서버 A: 중앙 대시보드
npm start

# 서버 B, C, D: 에이전트 설치
cd agent
sudo ./install.sh --central-dashboard http://serverA:3000
```

### 시나리오 3: 지역별 모니터링
```bash
# 한국 서버: 에이전트 설치
sudo ./install.sh --agent-name "Korea-Agent" --central-dashboard http://dashboard.company.com:3000

# 미국 서버: 에이전트 설치  
sudo ./install.sh --agent-name "US-Agent" --central-dashboard http://dashboard.company.com:3000
```

## 🔧 설정

### 중앙 대시보드 설정
```bash
# 환경 변수
export PORT=3000                    # 서버 포트
export NODE_ENV=production          # 운영 환경

# 실행
npm start
```

### 에이전트 설정
```bash
# 자동 설치 (대화형)
sudo ./install.sh

# 자동 설치 (무인)
sudo ./install.sh \
  --central-dashboard "http://dashboard.company.com:3000" \
  --agent-name "Production-Server-01" \
  --port 8080
```

## 📖 API 문서

### 에이전트 관리 API
```bash
GET    /api/agents              # 모든 에이전트 조회
GET    /api/agents/online       # 온라인 에이전트 조회
GET    /api/agents/:id          # 특정 에이전트 조회
POST   /api/agents/:id/assign   # 모니터링 할당
DELETE /api/agents/:id/monitors/:monitorId  # 모니터링 제거
```

### 모니터링 API
```bash
GET    /api/monitors            # 모든 모니터링 조회
POST   /api/monitors            # 모니터링 생성
PUT    /api/monitors/:id        # 모니터링 수정
DELETE /api/monitors/:id        # 모니터링 삭제
GET    /api/results             # 결과 조회
GET    /api/stats               # 통계 조회
```

## 🐳 Docker 배포

```bash
# 중앙 대시보드 Docker 실행
docker run -d \
  --name api-monitor-dashboard \
  -p 3000:3000 \
  api-monitor:latest

# 에이전트 Docker 실행
docker run -d \
  --name api-monitor-agent \
  -p 8080:8080 \
  -e CENTRAL_DASHBOARD="ws://dashboard-host:3000" \
  -e AGENT_NAME="Docker-Agent" \
  api-monitor-agent:latest
```

## 🚨 문제 해결

### 연결 문제
```bash
# 포트 확인
netstat -tuln | grep 3000

# 방화벽 확인
sudo ufw status
sudo ufw allow 3000
sudo ufw allow 8080
```

### 로그 확인
```bash
# 중앙 대시보드
npm start

# 에이전트 (systemd)
sudo journalctl -u api-monitor-agent -f

# 에이전트 (macOS)
tail -f /var/log/api-monitor-agent.log
```

## 🔄 업데이트

```bash
# 중앙 대시보드 업데이트
git pull origin main
npm install
npm start

# 에이전트 업데이트
cd agent
sudo ./install.sh  # 기존 설정 유지하며 업데이트
```

## 📞 지원

- **GitHub**: https://github.com/your-org/api-monitor
- **문서**: https://docs.api-monitor.com
- **이슈**: https://github.com/your-org/api-monitor/issues

---

**🎉 Happy Monitoring!**
EOF

# 압축 파일 생성
print_status "압축 파일 생성 중..."
tar -czf api-monitor-v1.0.0.tar.gz $DEPLOY_DIR

print_success "배포 패키지 생성 완료!"
echo ""
echo "📦 생성된 파일:"
echo "  - api-monitor-v1.0.0.tar.gz  (전체 패키지)"
echo "  - $DEPLOY_DIR/                (압축 해제된 파일들)"
echo ""
echo "🚀 배포 방법:"
echo "  1. 압축 파일을 대상 서버에 복사"
echo "  2. tar -xzf api-monitor-v1.0.0.tar.gz"
echo "  3. cd $DEPLOY_DIR"
echo "  4. ./quick-install.sh"
echo ""
echo "🤖 에이전트 설치:"
echo "  cd $DEPLOY_DIR/agent && sudo ./install.sh"